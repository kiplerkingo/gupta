# Gupta & Son E-commerce Platform

A complete, production-ready e-commerce platform built with React, TypeScript, Tailwind CSS, Supabase, and Razorpay integration.

## Features

### 🛍️ Core E-commerce Features
- **Product Catalog**: Browse products by categories with advanced filtering
- **Shopping Cart**: Add, remove, and manage items with quantity controls
- **User Authentication**: Secure login/signup system
- **Order Management**: Complete checkout process with order tracking
- **Wishlist**: Save favorite products for later
- **Search**: Intelligent product search functionality

### 💳 Payment Integration
- **Razorpay Integration**: Secure payment processing
- **Multiple Payment Methods**: Credit/Debit cards, UPI, Digital wallets, COD
- **Order Tracking**: Real-time order status updates

### 🗄️ Database & Backend
- **Supabase Database**: PostgreSQL with Row Level Security
- **Real-time Updates**: Live data synchronization
- **Secure API**: Protected endpoints with authentication

### 👨‍💼 Admin Panel
- **Product Management**: Add, edit, delete products
- **Order Management**: View and manage customer orders
- **User Management**: Monitor user accounts
- **Analytics Dashboard**: Sales and performance metrics

## Setup Instructions

### 1. Database Setup (Supabase)

1. **Create a Supabase Account**:
   - Go to [supabase.com](https://supabase.com)
   - Create a new account and project

2. **Connect to Supabase**:
   - Click the "Connect to Supabase" button in the top right of this interface
   - Follow the setup wizard to connect your project

3. **Database Schema**:
   - The database schema will be automatically created when you connect
   - Includes tables for users, products, and orders with proper security policies

### 2. Payment Gateway Setup (Razorpay)

Your Razorpay credentials are already configured:
- **Key ID**: `rzp_live_DHgoCXB1fFqzts`
- **Key Secret**: `y5SL5AXjlY0HMrGTvHaweiM4`

**Important**: These are live credentials. Ensure your Razorpay account is properly configured for production use.

### 3. Domain Configuration

The platform is configured for your domain: **guptaandson.in**

To deploy to your domain:
1. Build the project: `npm run build`
2. Deploy the `dist` folder to your web hosting
3. Configure your domain's DNS to point to your hosting provider

### 4. Admin Access

To access the admin panel:
1. Create a user account with email: `admin@guptaandson.in`
2. The admin button will appear in the header when logged in with this email
3. Use the admin panel to manage products, orders, and users

## Product Management

### Adding New Products

1. **Login as Admin**: Use `admin@guptaandson.in`
2. **Access Admin Panel**: Click the "Admin" button in the header
3. **Navigate to Products**: Click "Products" in the sidebar
4. **Add Product**: Click "Add Product" button
5. **Fill Details**:
   - Product name and brand
   - Pricing information
   - Category selection
   - Product images (use URLs)
   - Description and features
   - Specifications

### Updating Product Information

1. **Find Product**: In the admin products table
2. **Click Edit**: Use the edit icon next to the product
3. **Modify Details**: Update any field as needed
4. **Save Changes**: Click "Save Product"

### Managing Inventory

- **Stock Status**: Toggle in-stock/out-of-stock status
- **Pricing**: Update regular and sale prices
- **Delivery Options**: Configure fast delivery and free delivery

## Technical Architecture

### Frontend
- **React 18**: Modern React with hooks and context
- **TypeScript**: Type-safe development
- **Tailwind CSS**: Utility-first styling
- **Vite**: Fast build tool and dev server

### Backend & Database
- **Supabase**: PostgreSQL database with real-time features
- **Row Level Security**: Secure data access policies
- **Authentication**: Built-in user management

### Payment Processing
- **Razorpay**: Secure payment gateway
- **Multiple Methods**: Cards, UPI, wallets, COD
- **Order Tracking**: Payment status integration

## Security Features

- **Row Level Security**: Database-level access control
- **Authentication**: Secure user sessions
- **Payment Security**: PCI-compliant payment processing
- **Data Validation**: Input sanitization and validation

## Performance Optimizations

- **Code Splitting**: Lazy loading of components
- **Image Optimization**: Responsive images with proper sizing
- **Caching**: Efficient data caching strategies
- **Bundle Optimization**: Minimized JavaScript bundles

## Support & Maintenance

### Regular Tasks
1. **Monitor Orders**: Check admin dashboard daily
2. **Update Products**: Add new inventory regularly
3. **Customer Support**: Respond to user inquiries
4. **Analytics Review**: Monitor sales performance

### Troubleshooting
- **Payment Issues**: Check Razorpay dashboard
- **Database Problems**: Monitor Supabase logs
- **Performance**: Use browser dev tools for optimization

## Deployment Checklist

- [ ] Supabase database connected and configured
- [ ] Razorpay payment gateway tested
- [ ] Admin account created (`admin@guptaandson.in`)
- [ ] Sample products added
- [ ] Domain DNS configured
- [ ] SSL certificate installed
- [ ] Performance testing completed

Your e-commerce platform is now ready for production use at **guptaandson.in**!