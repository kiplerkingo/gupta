import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { ThemeProvider } from './context/ThemeContext';
import { LanguageProvider } from './context/LanguageContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Profile from './pages/Profile';
import AdminDashboard from './pages/AdminDashboard';
import CustomerService from './pages/CustomerService';
import HelpCenter from './pages/HelpCenter';
import Returns from './pages/Returns';
import Shipping from './pages/Shipping';
import TrackOrder from './pages/TrackOrder';
import About from './pages/About';
import Careers from './pages/Careers';
import Contact from './pages/Contact';
import SellOnPlatform from './pages/SellOnPlatform';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import NotFound from './pages/NotFound';

function App() {
  return (
    <AppProvider>
      <ThemeProvider>
        <LanguageProvider>
          <Router>
            <Routes>
              <Route path="/" element={<Layout />}>
                <Route index element={<Home />} />
                <Route path="product/:id" element={<ProductDetail />} />
                <Route path="cart" element={<Cart />} />
                <Route path="checkout" element={<Checkout />} />
                <Route path="profile" element={<Profile />} />
                <Route path="admin" element={<AdminDashboard />} />
                <Route path="customer-service" element={<CustomerService />} />
                <Route path="help" element={<HelpCenter />} />
                <Route path="returns" element={<Returns />} />
                <Route path="shipping" element={<Shipping />} />
                <Route path="track-order" element={<TrackOrder />} />
                <Route path="about" element={<About />} />
                <Route path="careers" element={<Careers />} />
                <Route path="contact" element={<Contact />} />
                <Route path="sell" element={<SellOnPlatform />} />
                <Route path="privacy" element={<PrivacyPolicy />} />
                <Route path="privacy-policy" element={<PrivacyPolicy />} />
                <Route path="terms" element={<TermsOfService />} />
                <Route path="returns-refunds" element={<Returns />} />
                <Route path="contact-us" element={<Contact />} />
                <Route path="*" element={<NotFound />} />
              </Route>
            </Routes>
          </Router>
        </LanguageProvider>
      </ThemeProvider>
    </AppProvider>
  );
}

export default App;