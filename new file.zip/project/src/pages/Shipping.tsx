import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Truck, Clock, MapPin, Package, Shield, Zap } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function Shipping() {
  const { isDark } = useTheme();
  const [selectedZone, setSelectedZone] = useState('metro');

  const shippingOptions = [
    {
      id: 'standard',
      name: 'Standard Delivery',
      icon: <Truck className="w-8 h-8" />,
      time: '3-7 business days',
      cost: 'Free on orders ₹500+',
      description: 'Regular delivery to your doorstep'
    },
    {
      id: 'express',
      name: 'Express Delivery',
      icon: <Zap className="w-8 h-8" />,
      time: '1-2 business days',
      cost: '₹99',
      description: 'Faster delivery for urgent orders'
    },
    {
      id: 'same-day',
      name: 'Same Day Delivery',
      icon: <Clock className="w-8 h-8" />,
      time: 'Within 24 hours',
      cost: '₹199',
      description: 'Available in select metro cities'
    }
  ];

  const deliveryZones = [
    {
      id: 'metro',
      name: 'Metro Cities',
      cities: ['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad'],
      standardTime: '1-3 days',
      expressTime: 'Same day',
      coverage: '100%'
    },
    {
      id: 'tier1',
      name: 'Tier 1 Cities',
      cities: ['Pune', 'Ahmedabad', 'Jaipur', 'Lucknow', 'Kanpur', 'Nagpur'],
      standardTime: '2-4 days',
      expressTime: '1-2 days',
      coverage: '95%'
    },
    {
      id: 'tier2',
      name: 'Tier 2 Cities',
      cities: ['Indore', 'Bhopal', 'Coimbatore', 'Kochi', 'Vadodara', 'Agra'],
      standardTime: '3-5 days',
      expressTime: '2-3 days',
      coverage: '90%'
    },
    {
      id: 'rural',
      name: 'Rural Areas',
      cities: ['Remote locations', 'Villages', 'Hill stations'],
      standardTime: '5-7 days',
      expressTime: '3-5 days',
      coverage: '85%'
    }
  ];

  const features = [
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'Secure Packaging',
      description: 'All items are carefully packed to prevent damage during transit'
    },
    {
      icon: <MapPin className="w-6 h-6" />,
      title: 'Real-time Tracking',
      description: 'Track your order from dispatch to delivery with live updates'
    },
    {
      icon: <Package className="w-6 h-6" />,
      title: 'Contactless Delivery',
      description: 'Safe delivery options including doorstep drop-off'
    }
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Shipping Information
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Fast, reliable delivery across India with multiple shipping options
          </p>
        </motion.div>

        {/* Shipping Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <h2 className={`text-2xl font-bold mb-6 text-center ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Delivery Options
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {shippingOptions.map((option) => (
              <motion.div
                key={option.id}
                whileHover={{ scale: 1.02 }}
                className={`p-6 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}
              >
                <div className={`p-4 rounded-full w-fit mx-auto mb-4 ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  {option.icon}
                </div>
                <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {option.name}
                </h3>
                <p className={`text-lg font-semibold mb-2 ${isDark ? 'text-green-400' : 'text-green-600'}`}>
                  {option.time}
                </p>
                <p className={`text-lg font-bold mb-3 ${isDark ? 'text-purple-400' : 'text-purple-600'}`}>
                  {option.cost}
                </p>
                <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  {option.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Delivery Zones */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-12"
        >
          <h2 className={`text-2xl font-bold mb-6 text-center ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Delivery Coverage
          </h2>
          
          {/* Zone Selector */}
          <div className="flex justify-center mb-8">
            <div className={`p-1 rounded-2xl ${isDark ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
              {deliveryZones.map((zone) => (
                <button
                  key={zone.id}
                  onClick={() => setSelectedZone(zone.id)}
                  className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                    selectedZone === zone.id
                      ? 'bg-purple-600 text-white'
                      : isDark
                      ? 'text-gray-300 hover:text-white'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  {zone.name}
                </button>
              ))}
            </div>
          </div>

          {/* Zone Details */}
          <div className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
            {deliveryZones.map((zone) => (
              selectedZone === zone.id && (
                <motion.div
                  key={zone.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid md:grid-cols-2 gap-8"
                >
                  <div>
                    <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      {zone.name}
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Standard Delivery:</span>
                        <span className={`font-semibold ${isDark ? 'text-white' : 'text-gray-800'}`}>{zone.standardTime}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Express Delivery:</span>
                        <span className={`font-semibold ${isDark ? 'text-white' : 'text-gray-800'}`}>{zone.expressTime}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Coverage:</span>
                        <span className={`font-semibold text-green-600`}>{zone.coverage}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className={`text-lg font-semibold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      Major Cities
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {zone.cities.map((city, index) => (
                        <span
                          key={index}
                          className={`px-3 py-1 rounded-full text-sm ${isDark ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}
                        >
                          {city}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )
            ))}
          </div>
        </motion.div>

        {/* Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-12"
        >
          <h2 className={`text-2xl font-bold mb-6 text-center ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Why Choose Our Shipping?
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`p-6 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
              >
                <div className={`p-3 rounded-full w-fit mx-auto mb-4 ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  {feature.icon}
                </div>
                <h3 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {feature.title}
                </h3>
                <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Shipping Calculator */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h3 className={`text-xl font-bold mb-6 text-center ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Calculate Shipping Cost
          </h3>
          <form className="max-w-md mx-auto space-y-4">
            <div>
              <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                Delivery Pincode
              </label>
              <input
                type="text"
                placeholder="Enter 6-digit pincode"
                className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
              />
            </div>
            <div>
              <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                Order Value
              </label>
              <input
                type="number"
                placeholder="Enter order amount"
                className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 px-6 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
            >
              Calculate Shipping
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}