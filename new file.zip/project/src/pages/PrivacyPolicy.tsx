import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Lock, Eye, UserCheck, Database, Globe } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function PrivacyPolicy() {
  const { isDark } = useTheme();

  const sections = [
    {
      icon: <Database className="w-8 h-8" />,
      title: "Information We Collect",
      content: [
        "Personal information you provide when creating an account (name, email, phone number)",
        "Payment information processed securely through our payment partners",
        "Shipping addresses and delivery preferences",
        "Product reviews, ratings, and feedback",
        "Website usage data and analytics",
        "Device information and browser details"
      ]
    },
    {
      icon: <Eye className="w-8 h-8" />,
      title: "How We Use Your Information",
      content: [
        "Process and fulfill your orders",
        "Provide customer support and respond to inquiries",
        "Send order confirmations and shipping updates",
        "Improve our products and services",
        "Personalize your shopping experience",
        "Prevent fraud and ensure platform security"
      ]
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Information Sharing",
      content: [
        "We never sell your personal information to third parties",
        "Shipping partners receive only necessary delivery information",
        "Payment processors handle financial data securely",
        "Analytics providers receive anonymized usage data",
        "Legal authorities may receive information when required by law",
        "Business partners may receive aggregated, non-personal data"
      ]
    },
    {
      icon: <Lock className="w-8 h-8" />,
      title: "Data Security",
      content: [
        "Industry-standard encryption for all data transmission",
        "Secure servers with regular security audits",
        "Limited access to personal information by authorized personnel only",
        "Regular security updates and monitoring",
        "Secure payment processing through certified partners",
        "Data backup and recovery procedures"
      ]
    },
    {
      icon: <UserCheck className="w-8 h-8" />,
      title: "Your Rights",
      content: [
        "Access your personal information at any time",
        "Update or correct your account information",
        "Delete your account and associated data",
        "Opt-out of marketing communications",
        "Request data portability",
        "File complaints with data protection authorities"
      ]
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: "Cookies and Tracking",
      content: [
        "Essential cookies for website functionality",
        "Analytics cookies to understand user behavior",
        "Preference cookies to remember your settings",
        "Marketing cookies for personalized advertisements",
        "You can control cookie preferences in your browser",
        "Some features may not work without certain cookies"
      ]
    }
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Privacy Policy
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Your privacy is important to us. This policy explains how we collect, use, and protect your information.
          </p>
          <p className={`text-sm mt-2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            Last updated: January 2025
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`p-6 rounded-2xl mb-8 ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h2 className={`text-2xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Our Commitment to Privacy
          </h2>
          <p className={`text-lg leading-relaxed ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            At Gupta & Sons, we are committed to protecting your privacy and ensuring the security of your personal information. 
            This Privacy Policy outlines our practices regarding the collection, use, and disclosure of information when you use our service.
          </p>
        </motion.div>

        <div className="space-y-8">
          {sections.map((section, index) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * index }}
              className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
            >
              <div className="flex items-center gap-4 mb-4">
                <div className={`p-3 rounded-full ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  {section.icon}
                </div>
                <h3 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {section.title}
                </h3>
              </div>
              <ul className="space-y-2">
                {section.content.map((item, itemIndex) => (
                  <li key={itemIndex} className={`flex items-start gap-3 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    <span className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className={`mt-12 p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Contact Us About Privacy
          </h3>
          <p className={`mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            If you have any questions about this Privacy Policy or our data practices, please contact us:
          </p>
          <div className={`space-y-2 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            <p><strong>Email:</strong> privacy@guptaandson.in</p>
            <p><strong>Phone:</strong> +91 8839107369</p>
            <p><strong>Address:</strong> Bhopal, Madhya Pradesh, India</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className={`mt-8 p-4 rounded-xl ${isDark ? 'bg-blue-900/50 border border-blue-700' : 'bg-blue-50 border border-blue-200'}`}
        >
          <p className={`text-sm ${isDark ? 'text-blue-300' : 'text-blue-700'}`}>
            <strong>Note:</strong> This Privacy Policy may be updated from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
          </p>
        </motion.div>
      </div>
    </div>
  );
}