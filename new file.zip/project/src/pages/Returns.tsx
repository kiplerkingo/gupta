import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Package, Clock, CheckCircle, XCircle, ArrowLeft, Calendar } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function Returns() {
  const { isDark } = useTheme();
  const [activeTab, setActiveTab] = useState('policy');

  const returnSteps = [
    {
      step: 1,
      title: 'Initiate Return',
      description: 'Log into your account and select the item you want to return',
      icon: <Package className="w-6 h-6" />
    },
    {
      step: 2,
      title: 'Print Return Label',
      description: 'Download and print the prepaid return shipping label',
      icon: <CheckCircle className="w-6 h-6" />
    },
    {
      step: 3,
      title: 'Pack & Ship',
      description: 'Pack the item securely and drop it off at any courier location',
      icon: <ArrowLeft className="w-6 h-6" />
    },
    {
      step: 4,
      title: 'Get Refund',
      description: 'Receive your refund within 5-7 business days after we receive the item',
      icon: <CheckCircle className="w-6 h-6" />
    }
  ];

  const returnReasons = [
    'Item not as described',
    'Wrong size/color received',
    'Defective or damaged item',
    'Changed my mind',
    'Better price found elsewhere',
    'Item arrived late'
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Returns & Refunds
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Easy returns within 30 days. No questions asked.
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex justify-center mb-8"
        >
          <div className={`p-1 rounded-2xl ${isDark ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
            <button
              onClick={() => setActiveTab('policy')}
              className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                activeTab === 'policy'
                  ? 'bg-purple-600 text-white'
                  : isDark
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Return Policy
            </button>
            <button
              onClick={() => setActiveTab('process')}
              className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                activeTab === 'process'
                  ? 'bg-purple-600 text-white'
                  : isDark
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Return Process
            </button>
            <button
              onClick={() => setActiveTab('track')}
              className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                activeTab === 'track'
                  ? 'bg-purple-600 text-white'
                  : isDark
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Track Return
            </button>
          </div>
        </motion.div>

        {activeTab === 'policy' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            {/* Policy Overview */}
            <div className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
              <h2 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                Our Return Policy
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${isDark ? 'bg-green-900 text-green-300' : 'bg-green-100 text-green-600'}`}>
                    <Calendar className="w-8 h-8" />
                  </div>
                  <h3 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>30 Days</h3>
                  <p className={isDark ? 'text-gray-300' : 'text-gray-600'}>Return window from delivery date</p>
                </div>
                <div className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${isDark ? 'bg-blue-900 text-blue-300' : 'bg-blue-100 text-blue-600'}`}>
                    <Package className="w-8 h-8" />
                  </div>
                  <h3 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>Free Returns</h3>
                  <p className={isDark ? 'text-gray-300' : 'text-gray-600'}>No return shipping charges</p>
                </div>
                <div className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h3 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>Quick Refunds</h3>
                  <p className={isDark ? 'text-gray-300' : 'text-gray-600'}>5-7 business days processing</p>
                </div>
              </div>
            </div>

            {/* Eligible Items */}
            <div className="grid md:grid-cols-2 gap-8">
              <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
                <h3 className={`text-xl font-bold mb-4 flex items-center gap-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  <CheckCircle className="text-green-500" size={24} />
                  Returnable Items
                </h3>
                <ul className={`space-y-2 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  <li>• Clothing with original tags</li>
                  <li>• Electronics in original packaging</li>
                  <li>• Books in good condition</li>
                  <li>• Home & kitchen items (unused)</li>
                  <li>• Beauty products (unopened)</li>
                  <li>• Sports & fitness equipment</li>
                </ul>
              </div>

              <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
                <h3 className={`text-xl font-bold mb-4 flex items-center gap-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  <XCircle className="text-red-500" size={24} />
                  Non-Returnable Items
                </h3>
                <ul className={`space-y-2 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  <li>• Personalized or customized items</li>
                  <li>• Perishable goods</li>
                  <li>• Intimate apparel</li>
                  <li>• Digital downloads</li>
                  <li>• Gift cards</li>
                  <li>• Items damaged by misuse</li>
                </ul>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'process' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            {/* Return Steps */}
            <div className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
              <h2 className={`text-2xl font-bold mb-8 text-center ${isDark ? 'text-white' : 'text-gray-800'}`}>
                How to Return an Item
              </h2>
              <div className="grid md:grid-cols-4 gap-6">
                {returnSteps.map((step, index) => (
                  <div key={step.step} className="text-center">
                    <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                      {step.icon}
                    </div>
                    <div className={`w-8 h-8 mx-auto mb-4 rounded-full flex items-center justify-center text-white font-bold ${isDark ? 'bg-purple-600' : 'bg-purple-600'}`}>
                      {step.step}
                    </div>
                    <h3 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      {step.title}
                    </h3>
                    <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                      {step.description}
                    </p>
                    {index < returnSteps.length - 1 && (
                      <div className={`hidden md:block absolute top-8 left-full w-full h-0.5 ${isDark ? 'bg-gray-600' : 'bg-gray-300'}`} />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Return Form */}
            <div className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
              <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                Start a Return
              </h3>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                      Order Number
                    </label>
                    <input
                      type="text"
                      placeholder="Enter your order number"
                      className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="Enter your email"
                      className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                    />
                  </div>
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                    Reason for Return
                  </label>
                  <select className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}>
                    <option value="">Select a reason</option>
                    {returnReasons.map((reason, index) => (
                      <option key={index} value={reason}>{reason}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                    Additional Comments (Optional)
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Tell us more about your return..."
                    className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3 px-6 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
                >
                  Submit Return Request
                </button>
              </form>
            </div>
          </motion.div>
        )}

        {activeTab === 'track' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h2 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Track Your Return
            </h2>
            <div className="max-w-md mx-auto">
              <div className="relative mb-6">
                <input
                  type="text"
                  placeholder="Enter return tracking number"
                  className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                />
                <button className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-1 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                  Track
                </button>
              </div>
              <div className={`p-6 rounded-xl ${isDark ? 'bg-gray-700' : 'bg-gray-50'} text-center`}>
                <Package className={`w-12 h-12 mx-auto mb-4 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                <p className={isDark ? 'text-gray-300' : 'text-gray-600'}>
                  Enter your return tracking number to see the status of your return.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}