import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Book, Video, FileText, MessageSquare, Star, ChevronRight } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function HelpCenter() {
  const { isDark } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('');

  const helpTopics = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: <Book className="w-6 h-6" />,
      articles: 12,
      description: 'Learn the basics of shopping with Gupta & Sons'
    },
    {
      id: 'orders',
      title: 'Orders & Shipping',
      icon: <FileText className="w-6 h-6" />,
      articles: 18,
      description: 'Everything about placing and tracking orders'
    },
    {
      id: 'payments',
      title: 'Payments & Billing',
      icon: <MessageSquare className="w-6 h-6" />,
      articles: 15,
      description: 'Payment methods, billing, and refunds'
    },
    {
      id: 'account',
      title: 'Account Management',
      icon: <Star className="w-6 h-6" />,
      articles: 10,
      description: 'Managing your profile and preferences'
    }
  ];

  const popularArticles = [
    {
      title: 'How to place an order',
      views: '15.2k views',
      category: 'Orders'
    },
    {
      title: 'Payment methods accepted',
      views: '12.8k views',
      category: 'Payments'
    },
    {
      title: 'How to track your order',
      views: '11.5k views',
      category: 'Orders'
    },
    {
      title: 'Return and refund policy',
      views: '9.3k views',
      category: 'Returns'
    },
    {
      title: 'Creating an account',
      views: '8.7k views',
      category: 'Account'
    }
  ];

  const videoTutorials = [
    {
      title: 'How to Shop on Gupta & Sons',
      duration: '3:45',
      thumbnail: 'https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg'
    },
    {
      title: 'Managing Your Wishlist',
      duration: '2:30',
      thumbnail: 'https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg'
    },
    {
      title: 'Using Filters and Search',
      duration: '4:15',
      thumbnail: 'https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg'
    }
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Help Center
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Find answers to your questions and learn how to make the most of Gupta & Sons
          </p>
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative mb-12"
        >
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={24} />
          <input
            type="text"
            placeholder="Search for help articles, guides, and tutorials..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-12 pr-4 py-4 text-lg rounded-2xl border-2 ${isDark ? 'bg-gray-800 border-gray-600 text-white' : 'bg-white border-purple-200'} focus:outline-none focus:ring-2 focus:ring-purple-500 shadow-lg`}
          />
        </motion.div>

        {/* Help Topics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-12"
        >
          <h2 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Browse by Topic
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {helpTopics.map((topic) => (
              <motion.div
                key={topic.id}
                whileHover={{ scale: 1.02 }}
                className={`p-6 rounded-2xl cursor-pointer transition-all ${isDark ? 'bg-gray-800 border border-gray-700 hover:border-purple-500' : 'bg-white border border-purple-100 hover:border-purple-300'} shadow-lg hover:shadow-xl`}
                onClick={() => setSelectedTopic(topic.id)}
              >
                <div className={`p-3 rounded-xl mb-4 w-fit ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  {topic.icon}
                </div>
                <h3 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {topic.title}
                </h3>
                <p className={`text-sm mb-3 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  {topic.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                    {topic.articles} articles
                  </span>
                  <ChevronRight className={isDark ? 'text-gray-400' : 'text-gray-500'} size={16} />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Popular Articles */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Popular Articles
            </h3>
            <div className="space-y-4">
              {popularArticles.map((article, index) => (
                <div key={index} className={`p-4 rounded-xl cursor-pointer transition-colors ${isDark ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}`}>
                  <h4 className={`font-semibold mb-1 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                    {article.title}
                  </h4>
                  <div className="flex items-center gap-3 text-sm">
                    <span className={`px-2 py-1 rounded-full ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                      {article.category}
                    </span>
                    <span className={isDark ? 'text-gray-400' : 'text-gray-500'}>
                      {article.views}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Video Tutorials */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8 }}
            className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Video Tutorials
            </h3>
            <div className="space-y-4">
              {videoTutorials.map((video, index) => (
                <div key={index} className={`flex gap-4 p-4 rounded-xl cursor-pointer transition-colors ${isDark ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}`}>
                  <div className="relative">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-20 h-14 object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Video className="text-white" size={20} />
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black bg-opacity-75 text-white text-xs px-1 rounded">
                      {video.duration}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className={`font-semibold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      {video.title}
                    </h4>
                    <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      Watch tutorial
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Contact Support */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className={`mt-12 p-8 rounded-2xl text-center ${isDark ? 'bg-gradient-to-r from-purple-900 to-pink-900' : 'bg-gradient-to-r from-purple-600 to-pink-600'} text-white`}
        >
          <h3 className="text-2xl font-bold mb-4">Still need help?</h3>
          <p className="text-lg mb-6 opacity-90">
            Can't find what you're looking for? Our support team is here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-3 bg-white text-purple-600 rounded-full font-semibold hover:bg-gray-100 transition-colors">
              Contact Support
            </button>
            <button className="px-8 py-3 border-2 border-white text-white rounded-full font-semibold hover:bg-white hover:text-purple-600 transition-colors">
              Live Chat
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}