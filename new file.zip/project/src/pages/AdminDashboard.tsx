import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { useTheme } from '../context/ThemeContext';
import AdminPanel from '../components/AdminPanel';

export default function AdminDashboard() {
  const { state } = useApp();
  const { isDark } = useTheme();
  const navigate = useNavigate();
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  useEffect(() => {
    // Check if user is authenticated and is admin
    if (!state.isAuthenticated) {
      navigate('/');
      return;
    }

    if (state.user?.email !== 'admin@guptaandson.in') {
      navigate('/');
      return;
    }

    setShowAdminPanel(true);
  }, [state.isAuthenticated, state.user, navigate]);

  if (!state.isAuthenticated || state.user?.email !== 'admin@guptaandson.in') {
    return (
      <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
        <div className="max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-center p-12 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h2 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Access Denied
            </h2>
            <p className={`text-lg mb-8 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              You don't have permission to access the admin dashboard.
            </p>
            <button
              onClick={() => navigate('/')}
              className="px-8 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
            >
              Go Home
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
      {showAdminPanel && (
        <AdminPanel onClose={() => navigate('/')} />
      )}
    </div>
  );
}