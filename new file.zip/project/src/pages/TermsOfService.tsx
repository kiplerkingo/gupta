import React from 'react';
import { motion } from 'framer-motion';
import { FileText, ShoppingCart, CreditCard, Truck, Shield, AlertTriangle } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function TermsOfService() {
  const { isDark } = useTheme();

  const sections = [
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Acceptance of Terms",
      content: [
        "By accessing and using Gupta & Sons platform, you accept and agree to be bound by these Terms of Service",
        "If you do not agree to these terms, please do not use our services",
        "These terms apply to all users, including browsers, vendors, customers, and contributors",
        "We reserve the right to update these terms at any time without prior notice",
        "Your continued use of the service constitutes acceptance of any changes"
      ]
    },
    {
      icon: <ShoppingCart className="w-8 h-8" />,
      title: "Use of Service",
      content: [
        "You must be at least 18 years old to use our services",
        "You are responsible for maintaining the confidentiality of your account",
        "You agree to provide accurate and complete information",
        "You may not use our service for any illegal or unauthorized purpose",
        "You must not transmit any viruses or malicious code",
        "We reserve the right to refuse service to anyone for any reason"
      ]
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: "Orders and Payments",
      content: [
        "All orders are subject to acceptance and availability",
        "Prices are subject to change without notice",
        "Payment must be received before order processing",
        "We accept various payment methods as displayed at checkout",
        "All transactions are processed securely through certified payment gateways",
        "You are responsible for any applicable taxes and fees"
      ]
    },
    {
      icon: <Truck className="w-8 h-8" />,
      title: "Shipping and Delivery",
      content: [
        "Delivery times are estimates and not guaranteed",
        "Risk of loss passes to you upon delivery to the carrier",
        "You must provide accurate shipping information",
        "Additional charges may apply for remote locations",
        "We are not responsible for delays caused by external factors",
        "Damaged or lost packages should be reported immediately"
      ]
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Returns and Refunds",
      content: [
        "Returns must be initiated within 30 days of delivery",
        "Items must be in original condition with tags attached",
        "Certain items may not be eligible for return",
        "Return shipping costs may be deducted from refunds",
        "Refunds will be processed within 5-7 business days",
        "Store credit may be offered in lieu of cash refunds"
      ]
    },
    {
      icon: <AlertTriangle className="w-8 h-8" />,
      title: "Limitation of Liability",
      content: [
        "Our liability is limited to the purchase price of the product",
        "We are not liable for indirect, incidental, or consequential damages",
        "We do not warrant that our service will be uninterrupted or error-free",
        "Product descriptions and images are for informational purposes only",
        "We are not responsible for third-party content or services",
        "Some jurisdictions may not allow limitation of liability"
      ]
    }
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Terms of Service
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Please read these terms carefully before using our services.
          </p>
          <p className={`text-sm mt-2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            Last updated: January 2025
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`p-6 rounded-2xl mb-8 ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h2 className={`text-2xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Welcome to Gupta & Sons
          </h2>
          <p className={`text-lg leading-relaxed ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            These Terms of Service ("Terms") govern your use of the Gupta & Sons e-commerce platform. 
            By using our service, you agree to these terms and our Privacy Policy. Please read them carefully.
          </p>
        </motion.div>

        <div className="space-y-8">
          {sections.map((section, index) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * index }}
              className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
            >
              <div className="flex items-center gap-4 mb-4">
                <div className={`p-3 rounded-full ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  {section.icon}
                </div>
                <h3 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {section.title}
                </h3>
              </div>
              <ul className="space-y-2">
                {section.content.map((item, itemIndex) => (
                  <li key={itemIndex} className={`flex items-start gap-3 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    <span className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className={`mt-12 p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Governing Law
          </h3>
          <p className={`mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            These Terms shall be governed by and construed in accordance with the laws of India. 
            Any disputes arising under these Terms shall be subject to the exclusive jurisdiction of the courts in Bhopal, Madhya Pradesh.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className={`mt-8 p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Contact Information
          </h3>
          <p className={`mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            If you have any questions about these Terms of Service, please contact us:
          </p>
          <div className={`space-y-2 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            <p><strong>Email:</strong> legal@guptaandson.in</p>
            <p><strong>Phone:</strong> +91 8839107369</p>
            <p><strong>Address:</strong> Bhopal, Madhya Pradesh, India</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className={`mt-8 p-4 rounded-xl ${isDark ? 'bg-yellow-900/50 border border-yellow-700' : 'bg-yellow-50 border border-yellow-200'}`}
        >
          <p className={`text-sm ${isDark ? 'text-yellow-300' : 'text-yellow-700'}`}>
            <strong>Important:</strong> These terms may be updated periodically. Continued use of our service after changes constitutes acceptance of the new terms.
          </p>
        </motion.div>
      </div>
    </div>
  );
}