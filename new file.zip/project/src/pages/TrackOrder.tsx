import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Package, Truck, CheckCircle, Clock, MapPin } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function TrackOrder() {
  const { isDark } = useTheme();
  const [trackingNumber, setTrackingNumber] = useState('');
  const [orderData, setOrderData] = useState(null);

  const mockOrderData = {
    orderId: 'GS123456789',
    status: 'shipped',
    estimatedDelivery: '2025-01-12',
    currentLocation: 'Mumbai Distribution Center',
    timeline: [
      {
        status: 'Order Placed',
        date: '2025-01-08',
        time: '10:30 AM',
        completed: true,
        icon: <Package className="w-5 h-5" />
      },
      {
        status: 'Order Confirmed',
        date: '2025-01-08',
        time: '11:15 AM',
        completed: true,
        icon: <CheckCircle className="w-5 h-5" />
      },
      {
        status: 'Shipped',
        date: '2025-01-09',
        time: '2:45 PM',
        completed: true,
        icon: <Truck className="w-5 h-5" />
      },
      {
        status: 'Out for Delivery',
        date: '2025-01-12',
        time: 'Expected',
        completed: false,
        icon: <MapPin className="w-5 h-5" />
      },
      {
        status: 'Delivered',
        date: '2025-01-12',
        time: 'Expected',
        completed: false,
        icon: <CheckCircle className="w-5 h-5" />
      }
    ],
    items: [
      {
        name: 'iPhone 15 Pro Max',
        quantity: 1,
        price: 159900,
        image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg'
      }
    ],
    shippingAddress: {
      name: 'John Doe',
      address: '123 Main Street, Apartment 4B',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001'
    }
  };

  const handleTrackOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (trackingNumber.trim()) {
      setOrderData(mockOrderData);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'shipped': return 'text-blue-600';
      case 'delivered': return 'text-green-600';
      case 'cancelled': return 'text-red-600';
      default: return 'text-yellow-600';
    }
  };

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Track Your Order
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Enter your order ID or tracking number to get real-time updates
          </p>
        </motion.div>

        {/* Tracking Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`p-8 rounded-2xl mb-8 ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <form onSubmit={handleTrackOrder} className="max-w-md mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                value={trackingNumber}
                onChange={(e) => setTrackingNumber(e.target.value)}
                placeholder="Enter Order ID (e.g., GS123456789)"
                className={`w-full pl-12 pr-4 py-4 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                required
              />
            </div>
            <button
              type="submit"
              className="w-full mt-4 py-3 px-6 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
            >
              Track Order
            </button>
          </form>
        </motion.div>

        {/* Order Details */}
        {orderData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-8"
          >
            {/* Order Summary */}
            <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <div>
                  <h2 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                    Order #{mockOrderData.orderId}
                  </h2>
                  <p className={`${getStatusColor(mockOrderData.status)} font-semibold capitalize`}>
                    {mockOrderData.status}
                  </p>
                </div>
                <div className="text-right mt-4 md:mt-0">
                  <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    Estimated Delivery
                  </p>
                  <p className={`text-lg font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                    {new Date(mockOrderData.estimatedDelivery).toLocaleDateString('en-IN', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
              </div>

              <div className={`p-4 rounded-xl ${isDark ? 'bg-blue-900/50 border border-blue-700' : 'bg-blue-50 border border-blue-200'}`}>
                <div className="flex items-center gap-3">
                  <MapPin className="text-blue-600" size={20} />
                  <div>
                    <p className={`font-semibold ${isDark ? 'text-blue-300' : 'text-blue-700'}`}>
                      Current Location
                    </p>
                    <p className={`${isDark ? 'text-blue-200' : 'text-blue-600'}`}>
                      {mockOrderData.currentLocation}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Timeline */}
            <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
              <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                Order Timeline
              </h3>
              <div className="space-y-4">
                {mockOrderData.timeline.map((event, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className={`p-2 rounded-full ${
                      event.completed 
                        ? 'bg-green-100 text-green-600' 
                        : isDark 
                        ? 'bg-gray-700 text-gray-400' 
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      {event.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className={`font-semibold ${
                          event.completed 
                            ? isDark ? 'text-white' : 'text-gray-800'
                            : isDark ? 'text-gray-400' : 'text-gray-500'
                        }`}>
                          {event.status}
                        </h4>
                        <span className={`text-sm ${
                          event.completed 
                            ? isDark ? 'text-gray-300' : 'text-gray-600'
                            : isDark ? 'text-gray-500' : 'text-gray-400'
                        }`}>
                          {event.date} {event.time}
                        </span>
                      </div>
                      {index < mockOrderData.timeline.length - 1 && (
                        <div className={`w-0.5 h-8 ml-2 mt-2 ${
                          event.completed ? 'bg-green-300' : isDark ? 'bg-gray-600' : 'bg-gray-300'
                        }`} />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Order Items */}
              <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
                <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  Order Items
                </h3>
                <div className="space-y-4">
                  {mockOrderData.items.map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className={`font-semibold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                          {item.name}
                        </h4>
                        <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                          Quantity: {item.quantity}
                        </p>
                        <p className={`font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                          {formatPrice(item.price)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Shipping Address */}
              <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
                <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  Shipping Address
                </h3>
                <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <p className={`font-semibold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                    {mockOrderData.shippingAddress.name}
                  </p>
                  <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    {mockOrderData.shippingAddress.address}
                  </p>
                  <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    {mockOrderData.shippingAddress.city}, {mockOrderData.shippingAddress.state}
                  </p>
                  <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    {mockOrderData.shippingAddress.pincode}
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className={`px-6 py-3 rounded-xl font-semibold transition-colors ${isDark ? 'bg-gray-700 hover:bg-gray-600 text-white' : 'bg-gray-200 hover:bg-gray-300 text-gray-800'}`}>
                Download Invoice
              </button>
              <button className="px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors">
                Contact Support
              </button>
            </div>
          </motion.div>
        )}

        {/* Help Section */}
        {!orderData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className={`p-8 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <Package className={`w-16 h-16 mx-auto mb-4 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Need Help Finding Your Order?
            </h3>
            <p className={`mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              You can find your order ID in the confirmation email we sent you, or in your account under "My Orders".
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className={`px-6 py-3 rounded-xl font-semibold transition-colors ${isDark ? 'bg-gray-700 hover:bg-gray-600 text-white' : 'bg-gray-200 hover:bg-gray-300 text-gray-800'}`}>
                View My Orders
              </button>
              <button className="px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors">
                Contact Support
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}