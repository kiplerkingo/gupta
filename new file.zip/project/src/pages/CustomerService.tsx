import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Phone, Mail, Clock, Search, ChevronDown, ChevronRight } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function CustomerService() {
  const { isDark } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);

  const categories = [
    { id: 'orders', name: 'Orders & Delivery', icon: '📦' },
    { id: 'returns', name: 'Returns & Refunds', icon: '↩️' },
    { id: 'payments', name: 'Payments & Billing', icon: '💳' },
    { id: 'account', name: 'Account & Profile', icon: '👤' },
    { id: 'technical', name: 'Technical Issues', icon: '🔧' },
    { id: 'other', name: 'Other Queries', icon: '❓' }
  ];

  const faqs = [
    {
      question: "How can I track my order?",
      answer: "You can track your order by visiting the 'Track Order' page and entering your order ID, or by logging into your account and viewing your order history."
    },
    {
      question: "What is your return policy?",
      answer: "We offer a 30-day return policy for most items. Items must be in original condition with tags attached. Some restrictions apply for certain categories."
    },
    {
      question: "How long does delivery take?",
      answer: "Standard delivery takes 3-7 business days. Express delivery is available for 1-2 business days in select cities."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept UPI, credit/debit cards, net banking, digital wallets, and cash on delivery (COD) for eligible orders."
    },
    {
      question: "How do I cancel my order?",
      answer: "You can cancel your order within 24 hours of placing it by visiting your order history or contacting customer support."
    }
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Customer Service
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            We're here to help! Get quick answers to your questions.
          </p>
        </motion.div>

        {/* Contact Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid md:grid-cols-3 gap-6 mb-12"
        >
          <div className={`p-6 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}>
            <Phone className={`w-12 h-12 mx-auto mb-4 ${isDark ? 'text-green-400' : 'text-green-600'}`} />
            <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>Call Us</h3>
            <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'} mb-3`}>Speak with our support team</p>
            <p className={`text-lg font-semibold ${isDark ? 'text-green-400' : 'text-green-600'}`}>+91 8839107369</p>
            <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Mon-Sat: 9 AM - 9 PM</p>
          </div>

          <div className={`p-6 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}>
            <MessageCircle className={`w-12 h-12 mx-auto mb-4 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
            <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>Live Chat</h3>
            <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'} mb-3`}>Chat with us instantly</p>
            <button className={`px-6 py-2 rounded-full ${isDark ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-600 hover:bg-blue-700'} text-white transition-colors`}>
              Start Chat
            </button>
          </div>

          <div className={`p-6 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}>
            <Mail className={`w-12 h-12 mx-auto mb-4 ${isDark ? 'text-purple-400' : 'text-purple-600'}`} />
            <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>Email Us</h3>
            <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'} mb-3`}>Send us your queries</p>
            <p className={`text-lg font-semibold ${isDark ? 'text-purple-400' : 'text-purple-600'}`}>support@guptaandson.in</p>
            <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Response within 24 hours</p>
          </div>
        </motion.div>

        {/* Search and Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className={`p-6 rounded-2xl mb-8 ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search for help..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full pl-10 pr-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
            />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`p-4 rounded-xl text-center transition-all ${
                  selectedCategory === category.id
                    ? 'bg-purple-600 text-white'
                    : isDark
                    ? 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                }`}
              >
                <div className="text-2xl mb-2">{category.icon}</div>
                <div className="text-sm font-medium">{category.name}</div>
              </button>
            ))}
          </div>
        </motion.div>

        {/* FAQ Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h2 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Frequently Asked Questions
          </h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className={`border rounded-xl ${isDark ? 'border-gray-600' : 'border-gray-200'}`}>
                <button
                  onClick={() => setExpandedFAQ(expandedFAQ === index ? null : index)}
                  className={`w-full p-4 text-left flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors ${isDark ? 'text-white' : 'text-gray-800'}`}
                >
                  <span className="font-medium">{faq.question}</span>
                  {expandedFAQ === index ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
                </button>
                {expandedFAQ === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className={`px-4 pb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}
                  >
                    {faq.answer}
                  </motion.div>
                )}
              </div>
            ))}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mt-8 grid md:grid-cols-2 gap-6"
        >
          <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>Quick Actions</h3>
            <div className="space-y-3">
              <button className={`w-full p-3 text-left rounded-lg ${isDark ? 'bg-gray-700 hover:bg-gray-600 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'} transition-colors`}>
                Track My Order
              </button>
              <button className={`w-full p-3 text-left rounded-lg ${isDark ? 'bg-gray-700 hover:bg-gray-600 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'} transition-colors`}>
                Return an Item
              </button>
              <button className={`w-full p-3 text-left rounded-lg ${isDark ? 'bg-gray-700 hover:bg-gray-600 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'} transition-colors`}>
                Cancel Order
              </button>
              <button className={`w-full p-3 text-left rounded-lg ${isDark ? 'bg-gray-700 hover:bg-gray-600 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'} transition-colors`}>
                Update Address
              </button>
            </div>
          </div>

          <div className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>Business Hours</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Monday - Friday</span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>9:00 AM - 9:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Saturday</span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>9:00 AM - 6:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Sunday</span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>Closed</span>
              </div>
            </div>
            <div className={`mt-4 p-3 rounded-lg ${isDark ? 'bg-green-900/50 border border-green-700' : 'bg-green-50 border border-green-200'}`}>
              <div className="flex items-center gap-2">
                <Clock className="text-green-600" size={16} />
                <span className={`text-sm font-medium ${isDark ? 'text-green-300' : 'text-green-700'}`}>
                  Currently Online
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}