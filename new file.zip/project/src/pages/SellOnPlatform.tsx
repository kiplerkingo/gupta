import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Store, TrendingUp, Users, Shield, Zap, Globe, CheckCircle, ArrowRight } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function SellOnPlatform() {
  const { isDark } = useTheme();
  const [activeStep, setActiveStep] = useState(1);

  const benefits = [
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Reach Millions',
      description: 'Access to 10+ million active customers across India',
      stat: '10M+ Customers'
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Boost Sales',
      description: 'Increase your revenue with our marketing tools and analytics',
      stat: '300% Avg Growth'
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Secure Payments',
      description: 'Fast, secure payments with multiple payment options',
      stat: '99.9% Success Rate'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Easy Management',
      description: 'Simple seller dashboard to manage inventory and orders',
      stat: '24/7 Support'
    }
  ];

  const steps = [
    {
      step: 1,
      title: 'Register',
      description: 'Create your seller account with basic business information',
      details: ['Business registration documents', 'Bank account details', 'Tax information', 'Identity verification']
    },
    {
      step: 2,
      title: 'List Products',
      description: 'Add your products with photos, descriptions, and pricing',
      details: ['Product photos (multiple angles)', 'Detailed descriptions', 'Competitive pricing', 'Inventory management']
    },
    {
      step: 3,
      title: 'Start Selling',
      description: 'Go live and start receiving orders from customers',
      details: ['Order notifications', 'Inventory tracking', 'Customer communication', 'Performance analytics']
    }
  ];

  const categories = [
    { name: 'Electronics', commission: '2-5%', icon: '📱' },
    { name: 'Fashion', commission: '5-15%', icon: '👕' },
    { name: 'Home & Kitchen', commission: '3-8%', icon: '🏠' },
    { name: 'Books', commission: '2-10%', icon: '📚' },
    { name: 'Sports', commission: '5-12%', icon: '⚽' },
    { name: 'Beauty', commission: '8-15%', icon: '💄' }
  ];

  const testimonials = [
    {
      name: 'Rajesh Kumar',
      business: 'Electronics Store',
      location: 'Mumbai',
      quote: 'Joining Gupta & Sons increased my sales by 400% in just 6 months!',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg'
    },
    {
      name: 'Priya Sharma',
      business: 'Fashion Boutique',
      location: 'Delhi',
      quote: 'The platform is so easy to use, and customer support is excellent.',
      image: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg'
    },
    {
      name: 'Amit Patel',
      business: 'Home Decor',
      location: 'Bangalore',
      quote: 'Best decision for my business. Great reach and reliable payments.',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg'
    }
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className={`text-5xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Sell on Gupta<span className="text-purple-600">&Sons</span>
          </h1>
          <p className={`text-xl leading-relaxed max-w-3xl mx-auto mb-8 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Join thousands of successful sellers and grow your business with India's fastest-growing e-commerce platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-4 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors text-lg">
              Start Selling Today
            </button>
            <button className={`px-8 py-4 rounded-xl font-semibold transition-colors text-lg ${isDark ? 'bg-gray-700 hover:bg-gray-600 text-white' : 'bg-white hover:bg-gray-50 text-gray-800 border border-gray-300'}`}>
              Learn More
            </button>
          </div>
        </motion.div>

        {/* Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <h2 className={`text-3xl font-bold text-center mb-12 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Why Sell With Us?
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
                className={`p-6 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}
              >
                <div className={`p-4 rounded-full w-fit mx-auto mb-4 ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  {benefit.icon}
                </div>
                <h3 className={`text-xl font-bold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {benefit.title}
                </h3>
                <p className={`mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  {benefit.description}
                </p>
                <div className={`text-lg font-bold ${isDark ? 'text-purple-400' : 'text-purple-600'}`}>
                  {benefit.stat}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* How It Works */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-16"
        >
          <h2 className={`text-3xl font-bold text-center mb-12 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            How It Works
          </h2>
          
          {/* Step Navigation */}
          <div className="flex justify-center mb-8">
            <div className={`p-1 rounded-2xl ${isDark ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
              {steps.map((step) => (
                <button
                  key={step.step}
                  onClick={() => setActiveStep(step.step)}
                  className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                    activeStep === step.step
                      ? 'bg-purple-600 text-white'
                      : isDark
                      ? 'text-gray-300 hover:text-white'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  Step {step.step}
                </button>
              ))}
            </div>
          </div>

          {/* Step Content */}
          <div className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
            {steps.map((step) => (
              activeStep === step.step && (
                <motion.div
                  key={step.step}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid md:grid-cols-2 gap-8 items-center"
                >
                  <div>
                    <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-4 ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                      {step.step}
                    </div>
                    <h3 className={`text-2xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      {step.title}
                    </h3>
                    <p className={`text-lg mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                      {step.description}
                    </p>
                    <ul className="space-y-2">
                      {step.details.map((detail, index) => (
                        <li key={index} className={`flex items-center gap-3 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                          <CheckCircle className="text-green-500" size={16} />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className={`p-6 rounded-xl ${isDark ? 'bg-gray-700' : 'bg-gray-50'} text-center`}>
                    <Store className={`w-24 h-24 mx-auto mb-4 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                    <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                      Visual representation of step {step.step}
                    </p>
                  </div>
                </motion.div>
              )
            ))}
          </div>
        </motion.div>

        {/* Categories & Commission */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mb-16"
        >
          <h2 className={`text-3xl font-bold text-center mb-12 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Categories & Commission Rates
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.0 + index * 0.1 }}
                className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-3xl">{category.icon}</div>
                  <div>
                    <h3 className={`text-lg font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      {category.name}
                    </h3>
                    <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      Commission: {category.commission}
                    </p>
                  </div>
                </div>
                <div className={`text-right ${isDark ? 'text-purple-400' : 'text-purple-600'}`}>
                  <ArrowRight size={20} />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="mb-16"
        >
          <h2 className={`text-3xl font-bold text-center mb-12 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Success Stories
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.4 + index * 0.1 }}
                className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
              >
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h4 className={`font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      {testimonial.name}
                    </h4>
                    <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      {testimonial.business}, {testimonial.location}
                    </p>
                  </div>
                </div>
                <p className={`italic ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  "{testimonial.quote}"
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.6 }}
          className={`p-12 rounded-2xl text-center ${isDark ? 'bg-gradient-to-r from-purple-900 to-pink-900' : 'bg-gradient-to-r from-purple-600 to-pink-600'} text-white`}
        >
          <h2 className="text-4xl font-bold mb-6">Ready to Start Selling?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of successful sellers and start growing your business today. 
            It's free to get started!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-4 bg-white text-purple-600 rounded-xl font-semibold hover:bg-gray-100 transition-colors text-lg">
              Register as Seller
            </button>
            <button className="px-8 py-4 border-2 border-white text-white rounded-xl font-semibold hover:bg-white hover:text-purple-600 transition-colors text-lg">
              Download Seller App
            </button>
          </div>
          <p className="text-sm mt-6 opacity-75">
            No setup fees • No monthly charges • Start selling in 24 hours
          </p>
        </motion.div>
      </div>
    </div>
  );
}