import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus, Trash2, ShoppingBag, ArrowRight, Shield, Truck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useTheme } from '../context/ThemeContext';
import { useNavigate } from 'react-router-dom';

export default function Cart() {
  const { state, dispatch } = useApp();
  const { isDark } = useTheme();
  const navigate = useNavigate();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity === 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: productId });
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { id: productId, quantity: newQuantity } });
    }
  };

  const removeItem = (productId: string) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: productId });
  };

  const subtotal = state.cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const deliveryCharges = subtotal > 500 ? 0 : 40;
  const tax = subtotal * 0.18; // 18% GST
  const total = subtotal + deliveryCharges + tax;

  const handleCheckout = () => {
    if (!state.isAuthenticated) {
      // Redirect to login or show auth modal
      alert('Please login to proceed with checkout');
      return;
    }
    navigate('/checkout');
  };

  if (state.cart.length === 0) {
    return (
      <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
        <div className="max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-center p-12 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <ShoppingBag size={80} className={`mx-auto mb-6 ${isDark ? 'text-gray-400' : 'text-gray-400'}`} />
            <h2 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Your cart is empty
            </h2>
            <p className={`text-lg mb-8 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              Looks like you haven't added anything to your cart yet. Start shopping to fill it up!
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate('/')}
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-2xl font-semibold hover:shadow-lg transition-all"
            >
              Continue Shopping
            </motion.button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className={`text-4xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Shopping Cart
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            {state.cart.length} {state.cart.length === 1 ? 'item' : 'items'} in your cart
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {state.cart.map((item, index) => (
              <motion.div
                key={item.product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
              >
                <div className="flex gap-6">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-24 h-24 object-cover rounded-xl"
                  />
                  <div className="flex-1">
                    <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                      {item.product.name}
                    </h3>
                    <p className={`text-sm mb-2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      by {item.product.brand}
                    </p>
                    <div className="flex items-center gap-4 mb-4">
                      {item.product.fastDelivery && (
                        <div className="flex items-center gap-1 text-green-600 text-sm">
                          <Truck size={14} />
                          <span>Fast Delivery</span>
                        </div>
                      )}
                      {item.product.freeDelivery && (
                        <div className="flex items-center gap-1 text-blue-600 text-sm">
                          <Shield size={14} />
                          <span>Free Delivery</span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className={`p-2 rounded-lg border transition-colors ${
                            isDark 
                              ? 'border-gray-600 hover:bg-gray-700' 
                              : 'border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          <Minus size={16} />
                        </button>
                        <span className={`px-4 py-2 border rounded-lg min-w-[60px] text-center font-semibold ${
                          isDark ? 'border-gray-600 text-white' : 'border-gray-300'
                        }`}>
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          className={`p-2 rounded-lg border transition-colors ${
                            isDark 
                              ? 'border-gray-600 hover:bg-gray-700' 
                              : 'border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                            {formatPrice(item.product.price * item.quantity)}
                          </div>
                          {item.product.originalPrice && (
                            <div className={`text-sm line-through ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
                              {formatPrice(item.product.originalPrice * item.quantity)}
                            </div>
                          )}
                        </div>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => removeItem(item.product.id)}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 size={20} />
                        </motion.button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className={`p-6 rounded-2xl h-fit sticky top-24 ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Order Summary
            </h3>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>
                  Subtotal ({state.cart.reduce((total, item) => total + item.quantity, 0)} items)
                </span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>
                  {formatPrice(subtotal)}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>
                  Delivery Charges
                </span>
                <span className={deliveryCharges === 0 ? 'text-green-600 font-semibold' : isDark ? 'text-white' : 'text-gray-800'}>
                  {deliveryCharges === 0 ? 'FREE' : formatPrice(deliveryCharges)}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>
                  Tax (GST 18%)
                </span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>
                  {formatPrice(tax)}
                </span>
              </div>
              
              <div className={`border-t pt-4 ${isDark ? 'border-gray-600' : 'border-gray-200'}`}>
                <div className="flex justify-between text-xl font-bold">
                  <span className={isDark ? 'text-white' : 'text-gray-800'}>Total</span>
                  <span className={isDark ? 'text-white' : 'text-gray-800'}>{formatPrice(total)}</span>
                </div>
              </div>
            </div>

            {/* Savings Info */}
            {subtotal > 500 && (
              <div className={`p-3 rounded-lg mb-6 ${isDark ? 'bg-green-900/50 border border-green-700' : 'bg-green-50 border border-green-200'}`}>
                <p className={`text-sm font-medium ${isDark ? 'text-green-300' : 'text-green-700'}`}>
                  🎉 You saved ₹40 on delivery charges!
                </p>
              </div>
            )}

            {/* Checkout Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleCheckout}
              className="w-full py-4 px-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-2xl font-semibold hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              Proceed to Checkout
              <ArrowRight size={20} />
            </motion.button>

            {/* Continue Shopping */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate('/')}
              className={`w-full mt-4 py-3 px-6 rounded-2xl font-semibold transition-all ${
                isDark 
                  ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
              }`}
            >
              Continue Shopping
            </motion.button>

            {/* Security Info */}
            <div className={`mt-6 p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
              <div className="flex items-center gap-2 mb-2">
                <Shield className="text-green-600" size={16} />
                <span className={`text-sm font-medium ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  Secure Checkout
                </span>
              </div>
              <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                Your payment information is encrypted and secure
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}