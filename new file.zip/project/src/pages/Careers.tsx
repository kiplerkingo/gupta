import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, MapPin, Clock, Users, Zap, Heart, Award, Coffee } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function Careers() {
  const { isDark } = useTheme();
  const [selectedDepartment, setSelectedDepartment] = useState('all');

  const benefits = [
    {
      icon: <Heart className="w-6 h-6" />,
      title: 'Health & Wellness',
      description: 'Comprehensive health insurance, mental health support, and wellness programs'
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: 'Learning & Growth',
      description: 'Continuous learning opportunities, skill development, and career advancement'
    },
    {
      icon: <Coffee className="w-6 h-6" />,
      title: 'Work-Life Balance',
      description: 'Flexible working hours, remote work options, and unlimited PTO'
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: 'Recognition',
      description: 'Performance bonuses, stock options, and employee recognition programs'
    }
  ];

  const departments = [
    { id: 'all', name: 'All Departments' },
    { id: 'engineering', name: 'Engineering' },
    { id: 'product', name: 'Product' },
    { id: 'design', name: 'Design' },
    { id: 'marketing', name: 'Marketing' },
    { id: 'operations', name: 'Operations' },
    { id: 'sales', name: 'Sales' }
  ];

  const jobs = [
    {
      id: 1,
      title: 'Senior Frontend Developer',
      department: 'engineering',
      location: 'Bangalore',
      type: 'Full-time',
      experience: '3-5 years',
      description: 'Build amazing user experiences with React, TypeScript, and modern web technologies.',
      skills: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js']
    },
    {
      id: 2,
      title: 'Product Manager',
      department: 'product',
      location: 'Mumbai',
      type: 'Full-time',
      experience: '4-6 years',
      description: 'Drive product strategy and execution for our e-commerce platform.',
      skills: ['Product Strategy', 'Analytics', 'User Research', 'Agile']
    },
    {
      id: 3,
      title: 'UX/UI Designer',
      department: 'design',
      location: 'Delhi',
      type: 'Full-time',
      experience: '2-4 years',
      description: 'Create intuitive and beautiful user experiences for millions of customers.',
      skills: ['Figma', 'User Research', 'Prototyping', 'Design Systems']
    },
    {
      id: 4,
      title: 'Digital Marketing Manager',
      department: 'marketing',
      location: 'Pune',
      type: 'Full-time',
      experience: '3-5 years',
      description: 'Lead digital marketing campaigns and drive customer acquisition.',
      skills: ['SEO/SEM', 'Social Media', 'Analytics', 'Content Marketing']
    },
    {
      id: 5,
      title: 'Operations Analyst',
      department: 'operations',
      location: 'Chennai',
      type: 'Full-time',
      experience: '1-3 years',
      description: 'Optimize supply chain and logistics operations across India.',
      skills: ['Data Analysis', 'SQL', 'Process Optimization', 'Excel']
    },
    {
      id: 6,
      title: 'Business Development Executive',
      department: 'sales',
      location: 'Hyderabad',
      type: 'Full-time',
      experience: '2-4 years',
      description: 'Build partnerships with sellers and expand our marketplace.',
      skills: ['Sales', 'Negotiation', 'Relationship Building', 'CRM']
    }
  ];

  const filteredJobs = selectedDepartment === 'all' 
    ? jobs 
    : jobs.filter(job => job.department === selectedDepartment);

  const stats = [
    { number: '500+', label: 'Team Members' },
    { number: '15+', label: 'Offices' },
    { number: '95%', label: 'Employee Satisfaction' },
    { number: '4.8/5', label: 'Glassdoor Rating' }
  ];

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className={`text-5xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Join Our Team
          </h1>
          <p className={`text-xl leading-relaxed max-w-3xl mx-auto ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Help us build the future of e-commerce in India. Join a team of passionate individuals 
            working to make commerce accessible to everyone.
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          {stats.map((stat, index) => (
            <div key={index} className={`text-center p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}>
              <div className={`text-3xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                {stat.number}
              </div>
              <div className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>

        {/* Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-16"
        >
          <h2 className={`text-3xl font-bold text-center mb-12 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Why Work With Us?
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                className={`p-6 rounded-2xl text-center ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}
              >
                <div className={`p-4 rounded-full w-fit mx-auto mb-4 ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  {benefit.icon}
                </div>
                <h3 className={`text-lg font-bold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {benefit.title}
                </h3>
                <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  {benefit.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Job Listings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mb-16"
        >
          <h2 className={`text-3xl font-bold text-center mb-8 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Open Positions
          </h2>

          {/* Department Filter */}
          <div className="flex justify-center mb-8">
            <div className={`p-1 rounded-2xl ${isDark ? 'bg-gray-800' : 'bg-white'} shadow-lg overflow-x-auto`}>
              <div className="flex gap-1">
                {departments.map((dept) => (
                  <button
                    key={dept.id}
                    onClick={() => setSelectedDepartment(dept.id)}
                    className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                      selectedDepartment === dept.id
                        ? 'bg-purple-600 text-white'
                        : isDark
                        ? 'text-gray-300 hover:text-white hover:bg-gray-700'
                        : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                    }`}
                  >
                    {dept.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Job Cards */}
          <div className="space-y-6">
            {filteredJobs.map((job, index) => (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.0 + index * 0.1 }}
                className={`p-6 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg hover:shadow-xl transition-all`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex-1">
                    <div className="flex items-start gap-4 mb-4">
                      <div className={`p-3 rounded-xl ${isDark ? 'bg-purple-900 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                        <Briefcase className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                          {job.title}
                        </h3>
                        <div className="flex flex-wrap gap-4 text-sm mb-3">
                          <div className="flex items-center gap-1">
                            <MapPin className={isDark ? 'text-gray-400' : 'text-gray-500'} size={16} />
                            <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>{job.location}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className={isDark ? 'text-gray-400' : 'text-gray-500'} size={16} />
                            <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>{job.type}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className={isDark ? 'text-gray-400' : 'text-gray-500'} size={16} />
                            <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>{job.experience}</span>
                          </div>
                        </div>
                        <p className={`mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                          {job.description}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {job.skills.map((skill, skillIndex) => (
                            <span
                              key={skillIndex}
                              className={`px-3 py-1 rounded-full text-sm ${isDark ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="lg:ml-6">
                    <button className="w-full lg:w-auto px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors">
                      Apply Now
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredJobs.length === 0 && (
            <div className={`text-center py-12 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
              <Briefcase className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">No positions available in this department right now.</p>
              <p>Check back soon or explore other departments!</p>
            </div>
          )}
        </motion.div>

        {/* Culture */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className={`p-8 rounded-2xl mb-16 ${isDark ? 'bg-gradient-to-r from-purple-900 to-pink-900' : 'bg-gradient-to-r from-purple-600 to-pink-600'} text-white`}
        >
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Our Culture</h2>
            <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
              We believe in creating an inclusive, diverse, and collaborative environment where 
              everyone can thrive and make a meaningful impact.
            </p>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-4xl mb-4">🚀</div>
                <h3 className="text-xl font-bold mb-2">Innovation First</h3>
                <p className="opacity-90">We encourage experimentation and creative problem-solving</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-4">🤝</div>
                <h3 className="text-xl font-bold mb-2">Collaboration</h3>
                <p className="opacity-90">We work together to achieve extraordinary results</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-4">🌱</div>
                <h3 className="text-xl font-bold mb-2">Growth Mindset</h3>
                <p className="opacity-90">We invest in continuous learning and development</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4 }}
          className={`text-center p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
        >
          <h3 className={`text-2xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Don't See the Right Role?
          </h3>
          <p className={`text-lg mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            We're always looking for talented individuals. Send us your resume and we'll keep you in mind for future opportunities.
          </p>
          <button className="px-8 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors">
            Send Your Resume
          </button>
        </motion.div>
      </div>
    </div>
  );
}