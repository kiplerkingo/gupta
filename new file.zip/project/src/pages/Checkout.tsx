import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Truck, Shield, ArrowLeft, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useTheme } from '../context/ThemeContext';
import { useNavigate } from 'react-router-dom';
import RazorpayCheckout from '../components/RazorpayCheckout';

export default function Checkout() {
  const { state, dispatch } = useApp();
  const { isDark } = useTheme();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [showPayment, setShowPayment] = useState(false);
  const [newAddress, setNewAddress] = useState({
    name: '',
    street: '',
    city: '',
    state: '',
    pincode: '',
    phone: '',
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const subtotal = state.cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const deliveryCharges = subtotal > 500 ? 0 : 40;
  const tax = subtotal * 0.18;
  const total = subtotal + deliveryCharges + tax;

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSelectedAddress(newAddress);
    setStep(2);
  };

  const handlePlaceOrder = () => {
    setShowPayment(true);
  };

  const handlePaymentSuccess = () => {
    dispatch({ type: 'CLEAR_CART' });
    setShowPayment(false);
    navigate('/profile?tab=orders');
  };

  if (!state.isAuthenticated) {
    return (
      <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
        <div className="max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-center p-12 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h2 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Please Login
            </h2>
            <p className={`text-lg mb-8 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              You need to login to proceed with checkout.
            </p>
            <button
              onClick={() => navigate('/')}
              className="px-8 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
            >
              Go Back
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  if (state.cart.length === 0) {
    return (
      <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
        <div className="max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-center p-12 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h2 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Your cart is empty
            </h2>
            <p className={`text-lg mb-8 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              Add some items to your cart before proceeding to checkout.
            </p>
            <button
              onClick={() => navigate('/')}
              className="px-8 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
            >
              Continue Shopping
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  if (showPayment) {
    return (
      <RazorpayCheckout
        onClose={() => setShowPayment(false)}
        onSuccess={handlePaymentSuccess}
        orderData={{
          items: state.cart,
          total,
          address: selectedAddress
        }}
      />
    );
  }

  return (
    <div className={`min-h-screen py-12 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'}`}>
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <button
            onClick={() => navigate('/cart')}
            className={`p-2 rounded-full hover:bg-gray-100 transition-colors ${isDark ? 'hover:bg-gray-700' : ''}`}
          >
            <ArrowLeft className={isDark ? 'text-white' : 'text-gray-600'} size={24} />
          </button>
          <h1 className={`text-4xl font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
            Checkout
          </h1>
        </motion.div>

        {/* Progress Indicator */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex items-center justify-center mb-12"
        >
          <div className="flex items-center">
            {[1, 2].map((stepNumber) => (
              <React.Fragment key={stepNumber}>
                <div className={`flex items-center justify-center w-10 h-10 rounded-full font-semibold ${
                  step >= stepNumber
                    ? 'bg-purple-600 text-white'
                    : isDark
                    ? 'bg-gray-700 text-gray-400'
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {step > stepNumber ? <Check size={20} /> : stepNumber}
                </div>
                {stepNumber < 2 && (
                  <div className={`w-16 h-1 mx-2 ${
                    step > stepNumber
                      ? 'bg-purple-600'
                      : isDark
                      ? 'bg-gray-700'
                      : 'bg-gray-200'
                  }`} />
                )}
              </React.Fragment>
            ))}
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Step 1: Address */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
              >
                <h3 className={`text-2xl font-bold mb-6 flex items-center gap-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  <MapPin size={24} />
                  Delivery Address
                </h3>
                <form onSubmit={handleAddressSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="Full Name"
                      value={newAddress.name}
                      onChange={(e) => setNewAddress({ ...newAddress, name: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                      required
                    />
                    <input
                      type="tel"
                      placeholder="Phone Number"
                      value={newAddress.phone}
                      onChange={(e) => setNewAddress({ ...newAddress, phone: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                      required
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Street Address"
                    value={newAddress.street}
                    onChange={(e) => setNewAddress({ ...newAddress, street: e.target.value })}
                    className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                    required
                  />
                  <div className="grid md:grid-cols-3 gap-4">
                    <input
                      type="text"
                      placeholder="City"
                      value={newAddress.city}
                      onChange={(e) => setNewAddress({ ...newAddress, city: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                      required
                    />
                    <input
                      type="text"
                      placeholder="State"
                      value={newAddress.state}
                      onChange={(e) => setNewAddress({ ...newAddress, state: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                      required
                    />
                    <input
                      type="text"
                      placeholder="PIN Code"
                      value={newAddress.pincode}
                      onChange={(e) => setNewAddress({ ...newAddress, pincode: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl border ${isDark ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-purple-500`}
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-4 px-6 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
                  >
                    Continue to Review Order
                  </button>
                </form>
              </motion.div>
            )}

            {/* Step 2: Review Order */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`p-8 rounded-2xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
              >
                <h3 className={`text-2xl font-bold mb-6 flex items-center gap-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  <Truck size={24} />
                  Review Your Order
                </h3>
                
                {/* Address Review */}
                <div className={`p-4 rounded-xl mb-6 ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <h4 className={`font-semibold mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                    Delivery Address
                  </h4>
                  <p className={isDark ? 'text-gray-300' : 'text-gray-600'}>
                    {selectedAddress?.name}<br />
                    {selectedAddress?.street}<br />
                    {selectedAddress?.city}, {selectedAddress?.state} - {selectedAddress?.pincode}<br />
                    Phone: {selectedAddress?.phone}
                  </p>
                </div>

                {/* Order Items */}
                <div className={`p-4 rounded-xl mb-6 ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <h4 className={`font-semibold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                    Order Items
                  </h4>
                  <div className="space-y-3">
                    {state.cart.map((item) => (
                      <div key={item.product.id} className="flex gap-4">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h5 className={`font-semibold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                            {item.product.name}
                          </h5>
                          <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                            Quantity: {item.quantity}
                          </p>
                          <p className={`font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>
                            {formatPrice(item.product.price * item.quantity)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handlePlaceOrder}
                  className="w-full py-4 px-6 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition-colors"
                >
                  Proceed to Payment
                </button>
              </motion.div>
            )}
          </div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className={`p-6 rounded-2xl h-fit sticky top-24 ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'} shadow-lg`}
          >
            <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Order Summary
            </h3>
            
            <div className="space-y-3 mb-6">
              {state.cart.map((item) => (
                <div key={item.product.id} className="flex justify-between text-sm">
                  <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>
                    {item.product.name} x {item.quantity}
                  </span>
                  <span className={isDark ? 'text-white' : 'text-gray-800'}>
                    {formatPrice(item.product.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>
            
            <div className={`border-t pt-4 space-y-2 ${isDark ? 'border-gray-600' : 'border-gray-200'}`}>
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Subtotal:</span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Delivery:</span>
                <span className={deliveryCharges === 0 ? 'text-green-600 font-semibold' : isDark ? 'text-white' : 'text-gray-800'}>
                  {deliveryCharges === 0 ? 'FREE' : formatPrice(deliveryCharges)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>Tax:</span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>{formatPrice(tax)}</span>
              </div>
              <div className={`flex justify-between text-xl font-bold border-t pt-2 ${isDark ? 'border-gray-600' : 'border-gray-200'}`}>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>Total:</span>
                <span className={isDark ? 'text-white' : 'text-gray-800'}>{formatPrice(total)}</span>
              </div>
            </div>

            {/* Security Badge */}
            <div className={`mt-6 p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
              <div className="flex items-center gap-2 mb-2">
                <Shield className="text-green-600" size={16} />
                <span className={`text-sm font-medium ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  Secure Checkout
                </span>
              </div>
              <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                Your payment information is encrypted and secure
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}