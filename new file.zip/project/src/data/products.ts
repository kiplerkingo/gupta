import { Product, Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Electronics',
    icon: 'Smartphone',
    subcategories: ['Mobiles', 'Laptops', 'Tablets', 'Cameras', 'Headphones']
  },
  {
    id: '2',
    name: 'Fashion',
    icon: 'Shirt',
    subcategories: ['Men', 'Women', 'Kids', 'Footwear', 'Accessories']
  },
  {
    id: '3',
    name: 'Home',
    icon: 'Home',
    subcategories: ['Furniture', 'Kitchen', 'Decor', 'Appliances', 'Storage']
  },
  {
    id: '4',
    name: 'Books',
    icon: 'Book',
    subcategories: ['Fiction', 'Non-Fiction', 'Educational', 'Comics', 'Children']
  },
  {
    id: '5',
    name: 'Sports',
    icon: 'Dumbbell',
    subcategories: ['Fitness', 'Outdoor', 'Team Sports', 'Individual Sports', 'Accessories']
  },
  {
    id: '6',
    name: 'Beauty',
    icon: 'Sparkles',
    subcategories: ['Skincare', 'Makeup', 'Hair Care', 'Fragrances', 'Personal Care']
  }
];

export const products: Product[] = [
  {
    id: '1',
    name: 'iPhone 15 Pro Max',
    price: 159900,
    originalPrice: 179900,
    discount: 11,
    rating: 4.6,
    reviews: 1247,
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg',
    images: [
      'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg',
      'https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg'
    ],
    category: 'Electronics',
    brand: 'Apple',
    description: 'The most advanced iPhone yet with titanium design, A17 Pro chip, and professional camera system.',
    features: ['6.7" Super Retina XDR display', 'A17 Pro chip', 'Pro camera system', 'Titanium design'],
    specifications: {
      'Screen Size': '6.7 inches',
      'Storage': '256GB',
      'RAM': '8GB',
      'Battery': '4441 mAh',
      'OS': 'iOS 17'
    },
    inStock: true,
    fastDelivery: true,
    freeDelivery: true
  },
  {
    id: '2',
    name: 'Samsung Galaxy S24 Ultra',
    price: 124999,
    originalPrice: 134999,
    discount: 7,
    rating: 4.5,
    reviews: 892,
    image: 'https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg',
    images: [
      'https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg',
      'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg'
    ],
    category: 'Electronics',
    brand: 'Samsung',
    description: 'Premium Android flagship with S Pen, exceptional cameras, and AI-powered features.',
    features: ['6.8" Dynamic AMOLED display', 'Snapdragon 8 Gen 3', 'S Pen included', '200MP camera'],
    specifications: {
      'Screen Size': '6.8 inches',
      'Storage': '256GB',
      'RAM': '12GB',
      'Battery': '5000 mAh',
      'OS': 'Android 14'
    },
    inStock: true,
    fastDelivery: true,
    freeDelivery: true
  },
  {
    id: '3',
    name: 'MacBook Pro 14" M3',
    price: 199900,
    originalPrice: 219900,
    discount: 9,
    rating: 4.8,
    reviews: 567,
    image: 'https://images.pexels.com/photos/812264/pexels-photo-812264.jpeg',
    images: [
      'https://images.pexels.com/photos/812264/pexels-photo-812264.jpeg',
      'https://images.pexels.com/photos/1591056/pexels-photo-1591056.jpeg'
    ],
    category: 'Electronics',
    brand: 'Apple',
    description: 'Professional laptop with M3 chip, stunning Liquid Retina XDR display, and all-day battery life.',
    features: ['14" Liquid Retina XDR display', 'M3 chip', '18-hour battery', 'Professional performance'],
    specifications: {
      'Screen Size': '14.2 inches',
      'Processor': 'Apple M3',
      'RAM': '16GB',
      'Storage': '512GB SSD',
      'OS': 'macOS Sonoma'
    },
    inStock: true,
    fastDelivery: false,
    freeDelivery: true
  },
  {
    id: '4',
    name: 'Nike Air Jordan 1 Retro High',
    price: 12295,
    originalPrice: 13995,
    discount: 12,
    rating: 4.4,
    reviews: 2156,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg',
    images: [
      'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg',
      'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg'
    ],
    category: 'Fashion',
    brand: 'Nike',
    description: 'Iconic basketball sneaker with premium leather construction and classic colorway.',
    features: ['Premium leather upper', 'Air-Sole unit', 'Rubber outsole', 'Classic design'],
    specifications: {
      'Material': 'Leather',
      'Sole': 'Rubber',
      'Closure': 'Laces',
      'Heel Height': '1 inch',
      'Weight': '450g'
    },
    inStock: true,
    fastDelivery: true,
    freeDelivery: false
  },
  {
    id: '5',
    name: 'Sony WH-1000XM5 Headphones',
    price: 29990,
    originalPrice: 34999,
    discount: 14,
    rating: 4.7,
    reviews: 1834,
    image: 'https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg',
    images: [
      'https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg',
      'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg'
    ],
    category: 'Electronics',
    brand: 'Sony',
    description: 'Industry-leading noise canceling headphones with exceptional sound quality and comfort.',
    features: ['Industry-leading noise canceling', '30-hour battery', 'Quick charge', 'Multipoint connection'],
    specifications: {
      'Type': 'Over-ear',
      'Battery Life': '30 hours',
      'Connectivity': 'Bluetooth 5.2',
      'Weight': '250g',
      'Driver Size': '30mm'
    },
    inStock: true,
    fastDelivery: true,
    freeDelivery: true
  },
  {
    id: '6',
    name: 'Levi\'s 511 Slim Jeans',
    price: 3999,
    originalPrice: 4999,
    discount: 20,
    rating: 4.3,
    reviews: 3421,
    image: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg',
    images: [
      'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg',
      'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg'
    ],
    category: 'Fashion',
    brand: 'Levi\'s',
    description: 'Classic slim-fit jeans with modern styling and comfortable stretch denim.',
    features: ['Slim fit', 'Stretch denim', 'Classic 5-pocket styling', 'Versatile design'],
    specifications: {
      'Fit': 'Slim',
      'Material': '99% Cotton, 1% Elastane',
      'Wash': 'Dark Blue',
      'Rise': 'Mid Rise',
      'Leg Opening': '14.5 inches'
    },
    inStock: true,
    fastDelivery: true,
    freeDelivery: false
  }
];