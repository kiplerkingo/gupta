import React, { createContext, useContext, useState } from 'react';

type Language = 'en' | 'hi' | 'ta';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    'nav.home': 'Home',
    'nav.categories': 'Categories',
    'nav.cart': 'Cart',
    'nav.wishlist': 'Wishlist',
    'nav.account': 'Account',
    'nav.admin': 'Admin',
    'hero.title': 'Welcome to Gupta & Sons',
    'hero.subtitle': 'India\'s Leading E-commerce Platform',
    'hero.description': 'Discover millions of products at unbeatable prices',
    'product.addToCart': 'Add to Cart',
    'product.addToWishlist': 'Add to Wishlist',
    'product.outOfStock': 'Out of Stock',
    'cart.empty': 'Your cart is empty',
    'cart.total': 'Total',
    'checkout.title': 'Checkout',
    'footer.customerService': 'Customer Service',
    'footer.about': 'About Gupta & Sons',
    'footer.contact': 'Contact Info'
  },
  hi: {
    'nav.home': 'होम',
    'nav.categories': 'श्रेणियां',
    'nav.cart': 'कार्ट',
    'nav.wishlist': 'विशलिस्ट',
    'nav.account': 'खाता',
    'nav.admin': 'एडमिन',
    'hero.title': 'गुप्ता एंड संस में आपका स्वागत है',
    'hero.subtitle': 'भारत का अग्रणी ई-कॉमर्स प्लेटफॉर्म',
    'hero.description': 'अजेय कीमतों पर लाखों उत्पादों की खोज करें',
    'product.addToCart': 'कार्ट में जोड़ें',
    'product.addToWishlist': 'विशलिस्ट में जोड़ें',
    'product.outOfStock': 'स्टॉक में नहीं',
    'cart.empty': 'आपका कार्ट खाली है',
    'cart.total': 'कुल',
    'checkout.title': 'चेकआउट',
    'footer.customerService': 'ग्राहक सेवा',
    'footer.about': 'गुप्ता एंड संस के बारे में',
    'footer.contact': 'संपर्क जानकारी'
  },
  ta: {
    'nav.home': 'முகப்பு',
    'nav.categories': 'வகைகள்',
    'nav.cart': 'கார்ட்',
    'nav.wishlist': 'விஷ்லிஸ்ட்',
    'nav.account': 'கணக்கு',
    'nav.admin': 'நிர்வாகி',
    'hero.title': 'குப்தா & சன்ஸ் வரவேற்கிறது',
    'hero.subtitle': 'இந்தியாவின் முன்னணி ஈ-காமர்ஸ் தளம்',
    'hero.description': 'அபராஜித விலையில் மில்லியன் கணக்கான தயாரிப்புகளை கண்டறியுங்கள்',
    'product.addToCart': 'கார்ட்டில் சேர்க்கவும்',
    'product.addToWishlist': 'விஷ்லிஸ்ட்டில் சேர்க்கவும்',
    'product.outOfStock': 'கையிருப்பில் இல்லை',
    'cart.empty': 'உங்கள் கார்ட் காலியாக உள்ளது',
    'cart.total': 'மொத்தம்',
    'checkout.title': 'செக்அவுட்',
    'footer.customerService': 'வாடிக்கையாளர் சேவை',
    'footer.about': 'குப்தா & சன்ஸ் பற்றி',
    'footer.contact': 'தொடர்பு தகவல்'
  }
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}