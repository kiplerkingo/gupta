import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Search, ShoppingCart, Heart, User, Menu, MapPin, Settings, 
  Sun, Moon, Globe, Bell, Package
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useTheme } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';
import AuthModal from './AuthModal';

export default function Header() {
  const { state } = useApp();
  const { isDark, toggleTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  const cartItemCount = state.cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <>
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`sticky top-0 z-50 backdrop-blur-md border-b transition-all duration-300 ${
          isDark 
            ? 'bg-gray-900/90 border-gray-700' 
            : 'bg-white/90 border-purple-200'
        }`}
      >
        {/* Top bar */}
        <div className={`py-2 text-xs ${
          isDark ? 'bg-gray-800 text-gray-300' : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
        }`}>
          <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link to="/help" className="hover:text-yellow-300 transition-colors">Download App</Link>
              <Link to="/sell" className="hover:text-yellow-300 transition-colors">Sell on Gupta & Sons</Link>
              <Link to="/customer-service" className="hover:text-yellow-300 transition-colors">Customer Care</Link>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <MapPin size={12} />
                <span>Bhopal, MP</span>
              </div>
              <button
                onClick={toggleTheme}
                className="p-1 hover:bg-white/20 rounded transition-colors"
              >
                {isDark ? <Sun size={14} /> : <Moon size={14} />}
              </button>
              <div className="relative">
                <button
                  onClick={() => setShowLanguageMenu(!showLanguageMenu)}
                  className="flex items-center gap-1 hover:bg-white/20 rounded px-2 py-1 transition-colors"
                >
                  <Globe size={14} />
                  <span>{language.toUpperCase()}</span>
                </button>
                {showLanguageMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`absolute right-0 mt-2 py-2 w-24 rounded-lg shadow-lg ${
                      isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'
                    }`}
                  >
                    {(['en', 'hi', 'ta'] as const).map((lang) => (
                      <button
                        key={lang}
                        onClick={() => {
                          setLanguage(lang);
                          setShowLanguageMenu(false);
                        }}
                        className={`block w-full text-left px-3 py-1 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 ${
                          language === lang ? 'font-semibold' : ''
                        }`}
                      >
                        {lang === 'en' ? 'English' : lang === 'hi' ? 'हिंदी' : 'தமிழ்'}
                      </button>
                    ))}
                  </motion.div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Main header */}
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className={`text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent`}
              >
                Gupta<span className="text-yellow-500">&Sons</span>
              </motion.div>
            </Link>

            {/* Search bar */}
            <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-2xl mx-8">
              <div className="relative w-full">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for products, brands and more"
                  className={`w-full px-6 py-3 rounded-full border-2 focus:outline-none transition-all ${
                    isDark 
                      ? 'bg-gray-800 border-gray-600 text-white focus:border-purple-500' 
                      : 'bg-white border-purple-200 text-gray-800 focus:border-purple-500'
                  } shadow-lg`}
                />
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full hover:shadow-lg transition-all"
                >
                  <Search size={20} />
                </motion.button>
              </div>
            </form>

            {/* Action buttons */}
            <div className="flex items-center gap-4">
              {state.isAuthenticated && state.user?.email === 'admin@guptaandson.in' && (
                <Link
                  to="/admin"
                  className="hidden md:flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-full hover:shadow-lg transition-all"
                >
                  <Settings size={20} />
                  <span>{t('nav.admin')}</span>
                </Link>
              )}

              <button
                onClick={() => {
                  if (state.isAuthenticated) {
                    navigate('/profile');
                  } else {
                    setShowAuthModal(true);
                  }
                }}
                className={`hidden md:flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
                  isDark 
                    ? 'bg-gray-800 text-white hover:bg-gray-700' 
                    : 'bg-white text-purple-600 hover:bg-purple-50'
                } shadow-lg`}
              >
                <User size={20} />
                <span>{state.isAuthenticated ? state.user?.name : 'Login'}</span>
              </button>

              <Link
                to="/profile?tab=wishlist"
                className={`hidden md:flex items-center gap-2 hover:text-pink-500 transition-colors relative ${
                  isDark ? 'text-gray-300' : 'text-gray-700'
                }`}
              >
                <Heart size={20} />
                <span>{t('nav.wishlist')}</span>
                {state.wishlist.length > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full"
                  >
                    {state.wishlist.length}
                  </motion.span>
                )}
              </Link>

              <Link
                to="/cart"
                className={`flex items-center gap-2 hover:text-purple-500 transition-colors relative ${
                  isDark ? 'text-gray-300' : 'text-gray-700'
                }`}
              >
                <ShoppingCart size={20} />
                <span className="hidden md:inline">{t('nav.cart')}</span>
                {cartItemCount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2 bg-purple-500 text-white text-xs px-1.5 py-0.5 rounded-full"
                  >
                    {cartItemCount}
                  </motion.span>
                )}
              </Link>

              <button className={`md:hidden p-2 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                <Menu size={24} />
              </button>
            </div>
          </div>

          {/* Mobile search */}
          <form onSubmit={handleSearchSubmit} className="md:hidden mt-4">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for products, brands and more"
                className={`w-full px-6 py-3 rounded-full border-2 focus:outline-none transition-all ${
                  isDark 
                    ? 'bg-gray-800 border-gray-600 text-white focus:border-purple-500' 
                    : 'bg-white border-purple-200 text-gray-800 focus:border-purple-500'
                }`}
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full"
              >
                <Search size={20} />
              </button>
            </div>
          </form>
        </div>

        {/* Categories navigation */}
        <div className={`border-t ${isDark ? 'border-gray-700 bg-gray-800' : 'border-purple-100 bg-white'}`}>
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-8 overflow-x-auto scrollbar-hide py-3">
              {['Electronics', 'Fashion', 'Home', 'Books', 'Sports', 'Beauty'].map((category) => (
                <Link
                  key={category}
                  to={`/?category=${category}`}
                  className={`whitespace-nowrap px-4 py-2 rounded-full transition-all hover:scale-105 ${
                    isDark 
                      ? 'text-gray-300 hover:bg-gray-700 hover:text-white' 
                      : 'text-gray-700 hover:bg-purple-100 hover:text-purple-600'
                  }`}
                >
                  {category}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </motion.header>

      {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
    </>
  );
}