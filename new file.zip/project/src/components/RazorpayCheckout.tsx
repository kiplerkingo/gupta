import React, { useState } from 'react';
import { X, CreditCard, Smartphone, Wallet } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';

interface RazorpayCheckoutProps {
  onClose: () => void;
  onSuccess: () => void;
  orderData: {
    items: any[];
    total: number;
    address: any;
  };
}

declare global {
  interface Window {
    Razorpay: any;
  }
}

export default function RazorpayCheckout({ onClose, onSuccess, orderData }: RazorpayCheckoutProps) {
  const { state } = useApp();
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [error, setError] = useState('');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const handlePayment = async () => {
    if (!state.user) {
      setError('Please login to continue');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      console.log('Starting payment process...');
      
      // Create order in database first
      const orderId = crypto.randomUUID();
      
      const orderItems = orderData.items.map(item => ({
        product_id: item.product.id,
        product_name: item.product.name,
        product_price: item.product.price,
        quantity: item.quantity,
        total: item.product.price * item.quantity
      }));

      console.log('Creating order with data:', {
        orderId,
        userId: state.user.id,
        items: orderItems,
        total: orderData.total,
        address: orderData.address
      });

      const { data: orderData_db, error: orderError } = await supabase
        .from('orders')
        .insert([{
          id: orderId,
          user_id: state.user.id,
          items: orderItems,
          total: orderData.total,
          status: 'pending',
          payment_status: 'pending',
          shipping_address: orderData.address,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select();

      if (orderError) {
        console.error('Order creation error:', orderError);
        throw new Error(`Failed to create order: ${orderError.message}`);
      }

      console.log('Order created successfully:', orderData_db);

      // Load Razorpay script if not already loaded
      await loadRazorpayScript();

      // Initialize Razorpay payment
      const options = {
        key: 'rzp_live_DHgoCXB1fFqzts',
        amount: Math.round(orderData.total * 100), // Convert to paise
        currency: 'INR',
        name: 'Gupta & Son',
        description: `Order #${orderId.slice(0, 8)}`,
        handler: async (response: any) => {
          try {
            console.log('Payment successful:', response);
            
            // Update order with payment details
            const { error: updateError } = await supabase
              .from('orders')
              .update({
                payment_id: response.razorpay_payment_id,
                payment_status: 'completed',
                status: 'confirmed',
                updated_at: new Date().toISOString()
              })
              .eq('id', orderId);

            if (updateError) {
              console.error('Order update error:', updateError);
              setError('Payment successful but order update failed. Contact support with payment ID: ' + response.razorpay_payment_id);
            } else {
              console.log('Order updated successfully');
              onSuccess();
            }
          } catch (error: any) {
            console.error('Error updating order:', error);
            setError('Payment successful but order update failed. Please contact support.');
          } finally {
            setLoading(false);
          }
        },
        prefill: {
          name: state.user.name,
          email: state.user.email,
          contact: state.user.phone || '9999999999'
        },
        theme: {
          color: '#2563eb'
        },
        modal: {
          ondismiss: () => {
            setLoading(false);
            setError('Payment was cancelled');
          }
        }
      };

      console.log('Initializing Razorpay with options:', {
        ...options,
        handler: '[Function]'
      });

      const razorpay = new window.Razorpay(options);
      razorpay.open();

    } catch (error: any) {
      console.error('Payment error:', error);
      setError(error.message || 'Payment initialization failed. Please try again.');
      setLoading(false);
    }
  };

  const loadRazorpayScript = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (window.Razorpay) {
        resolve();
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => {
        console.log('Razorpay script loaded successfully');
        resolve();
      };
      script.onerror = () => {
        console.error('Failed to load Razorpay script');
        reject(new Error('Failed to load payment gateway. Please check your internet connection.'));
      };
      document.body.appendChild(script);
    });
  };

  const handleCOD = async () => {
    if (!state.user) {
      setError('Please login to continue');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      console.log('Starting COD order process...');
      
      const orderId = crypto.randomUUID();
      
      const orderItems = orderData.items.map(item => ({
        product_id: item.product.id,
        product_name: item.product.name,
        product_price: item.product.price,
        quantity: item.quantity,
        total: item.product.price * item.quantity
      }));

      console.log('Creating COD order with data:', {
        orderId,
        userId: state.user.id,
        items: orderItems,
        total: orderData.total,
        address: orderData.address
      });

      const { data, error } = await supabase
        .from('orders')
        .insert([{
          id: orderId,
          user_id: state.user.id,
          items: orderItems,
          total: orderData.total,
          status: 'confirmed',
          payment_status: 'cod',
          shipping_address: orderData.address,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select();

      if (error) {
        console.error('COD order error:', error);
        throw new Error(`Failed to place COD order: ${error.message}`);
      }

      console.log('COD order created successfully:', data);
      onSuccess();
      
    } catch (error: any) {
      console.error('COD order error:', error);
      setError(error.message || 'Failed to place COD order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-gray-800">Payment</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
            {error}
          </div>
        )}

        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-4">Choose Payment Method</h3>
          <div className="space-y-3">
            <label className="flex items-center p-4 border border-gray-300 rounded-md cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="payment"
                value="card"
                checked={paymentMethod === 'card'}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="mr-3"
              />
              <CreditCard className="mr-3 text-blue-600" size={20} />
              <div>
                <div className="font-semibold">Credit/Debit Card</div>
                <div className="text-sm text-gray-600">Pay securely with Razorpay</div>
              </div>
            </label>

            <label className="flex items-center p-4 border border-gray-300 rounded-md cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="payment"
                value="upi"
                checked={paymentMethod === 'upi'}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="mr-3"
              />
              <Smartphone className="mr-3 text-green-600" size={20} />
              <div>
                <div className="font-semibold">UPI Payment</div>
                <div className="text-sm text-gray-600">Pay using Google Pay, PhonePe, Paytm</div>
              </div>
            </label>

            <label className="flex items-center p-4 border border-gray-300 rounded-md cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="payment"
                value="wallet"
                checked={paymentMethod === 'wallet'}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="mr-3"
              />
              <Wallet className="mr-3 text-purple-600" size={20} />
              <div>
                <div className="font-semibold">Digital Wallets</div>
                <div className="text-sm text-gray-600">Paytm, Mobikwik, Amazon Pay</div>
              </div>
            </label>

            <label className="flex items-center p-4 border border-gray-300 rounded-md cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                name="payment"
                value="cod"
                checked={paymentMethod === 'cod'}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="mr-3"
              />
              <div>
                <div className="font-semibold">Cash on Delivery</div>
                <div className="text-sm text-gray-600">Pay when you receive the order</div>
              </div>
            </label>
          </div>
        </div>

        <div className="border-t pt-4 mb-6">
          <div className="flex justify-between text-lg font-semibold">
            <span>Total Amount:</span>
            <span>{formatPrice(orderData.total)}</span>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={onClose}
            disabled={loading}
            className="flex-1 py-3 px-6 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={paymentMethod === 'cod' ? handleCOD : handlePayment}
            disabled={loading}
            className="flex-1 py-3 px-6 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {loading ? 'Processing...' : paymentMethod === 'cod' ? 'Place Order' : 'Pay Now'}
          </button>
        </div>
      </div>
    </div>
  );
}