import React from 'react';
import { ShoppingBag, Truck, Shield, Headphones } from 'lucide-react';

export default function Hero() {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Welcome to Gupta<span className="text-yellow-400">&Sons</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100">
            India's Leading E-commerce Platform
          </p>
          <p className="text-lg text-blue-200 max-w-2xl mx-auto">
            Discover millions of products at unbeatable prices. From electronics to fashion, 
            home essentials to books - find everything you need in one place.
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8 mt-12">
          <div className="text-center">
            <div className="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <ShoppingBag size={32} />
            </div>
            <h3 className="font-semibold mb-2">Wide Selection</h3>
            <p className="text-blue-200 text-sm">Millions of products across all categories</p>
          </div>
          
          <div className="text-center">
            <div className="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Truck size={32} />
            </div>
            <h3 className="font-semibold mb-2">Fast Delivery</h3>
            <p className="text-blue-200 text-sm">Quick and reliable delivery to your doorstep</p>
          </div>
          
          <div className="text-center">
            <div className="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Shield size={32} />
            </div>
            <h3 className="font-semibold mb-2">Secure Shopping</h3>
            <p className="text-blue-200 text-sm">Safe and secure payment options</p>
          </div>
          
          <div className="text-center">
            <div className="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Headphones size={32} />
            </div>
            <h3 className="font-semibold mb-2">24/7 Support</h3>
            <p className="text-blue-200 text-sm">Round-the-clock customer service</p>
          </div>
        </div>
      </div>
    </div>
  );
}