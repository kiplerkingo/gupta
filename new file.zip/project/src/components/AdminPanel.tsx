import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Save, X, Upload, Package, Users, ShoppingCart, TrendingUp, Eye, FileText } from 'lucide-react';
import { supabase, DatabaseProduct } from '../lib/supabase';

interface AdminPanelProps {
  onClose: () => void;
}

interface Order {
  id: string;
  user_id: string;
  items: any[];
  total: number;
  status: string;
  payment_id?: string;
  payment_status: string;
  shipping_address: any;
  created_at: string;
  updated_at: string;
  users?: {
    name: string;
    email: string;
    phone?: string;
  };
}

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [products, setProducts] = useState<DatabaseProduct[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [editingProduct, setEditingProduct] = useState<DatabaseProduct | null>(null);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    totalUsers: 0,
    totalRevenue: 0
  });

  const [newProduct, setNewProduct] = useState({
    name: '',
    price: 0,
    original_price: 0,
    discount: 0,
    rating: 4.0,
    reviews: 0,
    image: '',
    images: [''],
    category: 'Electronics',
    brand: '',
    description: '',
    features: [''],
    specifications: {},
    in_stock: true,
    fast_delivery: true,
    free_delivery: true
  });

  useEffect(() => {
    if (activeTab === 'products') {
      fetchProducts();
    } else if (activeTab === 'orders') {
      fetchOrders();
    } else if (activeTab === 'dashboard') {
      fetchStats();
    }
  }, [activeTab]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          users (
            name,
            email,
            phone
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOrders(data || []);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const [productsRes, ordersRes, usersRes] = await Promise.all([
        supabase.from('products').select('id', { count: 'exact' }),
        supabase.from('orders').select('id, total', { count: 'exact' }),
        supabase.from('users').select('id', { count: 'exact' })
      ]);

      const totalRevenue = ordersRes.data?.reduce((sum, order) => sum + order.total, 0) || 0;

      setStats({
        totalProducts: productsRes.count || 0,
        totalOrders: ordersRes.count || 0,
        totalUsers: usersRes.count || 0,
        totalRevenue
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleSaveProduct = async () => {
    setLoading(true);
    try {
      const productData = {
        ...newProduct,
        features: newProduct.features.filter(f => f.trim() !== ''),
        images: newProduct.images.filter(img => img.trim() !== ''),
        updated_at: new Date().toISOString()
      };

      if (editingProduct) {
        const { error } = await supabase
          .from('products')
          .update(productData)
          .eq('id', editingProduct.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('products')
          .insert([{
            ...productData,
            id: crypto.randomUUID(),
            created_at: new Date().toISOString()
          }]);

        if (error) throw error;
      }

      setIsAddingProduct(false);
      setEditingProduct(null);
      resetProductForm();
      fetchProducts();
    } catch (error) {
      console.error('Error saving product:', error);
      alert('Error saving product. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: string) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('orders')
        .update({
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', orderId);

      if (error) throw error;
      fetchOrders();
    } catch (error) {
      console.error('Error updating order status:', error);
      alert('Error updating order status. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;
      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Error deleting product. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleEditProduct = (product: DatabaseProduct) => {
    setEditingProduct(product);
    setNewProduct({
      name: product.name,
      price: product.price,
      original_price: product.original_price || 0,
      discount: product.discount || 0,
      rating: product.rating,
      reviews: product.reviews,
      image: product.image,
      images: product.images,
      category: product.category,
      brand: product.brand,
      description: product.description,
      features: product.features,
      specifications: product.specifications,
      in_stock: product.in_stock,
      fast_delivery: product.fast_delivery,
      free_delivery: product.free_delivery
    });
    setIsAddingProduct(true);
  };

  const resetProductForm = () => {
    setNewProduct({
      name: '',
      price: 0,
      original_price: 0,
      discount: 0,
      rating: 4.0,
      reviews: 0,
      image: '',
      images: [''],
      category: 'Electronics',
      brand: '',
      description: '',
      features: [''],
      specifications: {},
      in_stock: true,
      fast_delivery: true,
      free_delivery: true
    });
  };

  const addFeature = () => {
    setNewProduct({
      ...newProduct,
      features: [...newProduct.features, '']
    });
  };

  const updateFeature = (index: number, value: string) => {
    const updatedFeatures = [...newProduct.features];
    updatedFeatures[index] = value;
    setNewProduct({
      ...newProduct,
      features: updatedFeatures
    });
  };

  const removeFeature = (index: number) => {
    setNewProduct({
      ...newProduct,
      features: newProduct.features.filter((_, i) => i !== index)
    });
  };

  const addImage = () => {
    setNewProduct({
      ...newProduct,
      images: [...newProduct.images, '']
    });
  };

  const updateImage = (index: number, value: string) => {
    const updatedImages = [...newProduct.images];
    updatedImages[index] = value;
    setNewProduct({
      ...newProduct,
      images: updatedImages
    });
  };

  const removeImage = (index: number) => {
    setNewProduct({
      ...newProduct,
      images: newProduct.images.filter((_, i) => i !== index)
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'confirmed': return 'bg-blue-100 text-blue-800';
      case 'shipped': return 'bg-purple-100 text-purple-800';
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex">
      <div className="bg-white w-full max-w-7xl mx-auto my-4 rounded-lg overflow-hidden flex">
        {/* Sidebar */}
        <div className="w-64 bg-gray-900 text-white p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold">Admin Panel</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-700 rounded-full transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          <nav className="space-y-2">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`w-full text-left p-3 rounded-lg transition-colors flex items-center gap-3 ${
                activeTab === 'dashboard' ? 'bg-blue-600' : 'hover:bg-gray-700'
              }`}
            >
              <TrendingUp size={20} />
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`w-full text-left p-3 rounded-lg transition-colors flex items-center gap-3 ${
                activeTab === 'products' ? 'bg-blue-600' : 'hover:bg-gray-700'
              }`}
            >
              <Package size={20} />
              Products
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full text-left p-3 rounded-lg transition-colors flex items-center gap-3 ${
                activeTab === 'orders' ? 'bg-blue-600' : 'hover:bg-gray-700'
              }`}
            >
              <ShoppingCart size={20} />
              Orders
            </button>
            <button
              onClick={() => setActiveTab('add-product')}
              className={`w-full text-left p-3 rounded-lg transition-colors flex items-center gap-3 ${
                activeTab === 'add-product' ? 'bg-blue-600' : 'hover:bg-gray-700'
              }`}
            >
              <Plus size={20} />
              Add Product
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`w-full text-left p-3 rounded-lg transition-colors flex items-center gap-3 ${
                activeTab === 'users' ? 'bg-blue-600' : 'hover:bg-gray-700'
              }`}
            >
              <Users size={20} />
              Users
            </button>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <div className="p-6">
              <h3 className="text-2xl font-bold mb-6">Dashboard</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-600 text-sm font-medium">Total Products</p>
                      <p className="text-2xl font-bold text-blue-900">{stats.totalProducts}</p>
                    </div>
                    <Package className="text-blue-600" size={32} />
                  </div>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-600 text-sm font-medium">Total Orders</p>
                      <p className="text-2xl font-bold text-green-900">{stats.totalOrders}</p>
                    </div>
                    <ShoppingCart className="text-green-600" size={32} />
                  </div>
                </div>
                <div className="bg-purple-50 p-6 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-600 text-sm font-medium">Total Users</p>
                      <p className="text-2xl font-bold text-purple-900">{stats.totalUsers}</p>
                    </div>
                    <Users className="text-purple-600" size={32} />
                  </div>
                </div>
                <div className="bg-yellow-50 p-6 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-yellow-600 text-sm font-medium">Total Revenue</p>
                      <p className="text-2xl font-bold text-yellow-900">{formatPrice(stats.totalRevenue)}</p>
                    </div>
                    <TrendingUp className="text-yellow-600" size={32} />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold">Products Management</h3>
                <button
                  onClick={() => setActiveTab('add-product')}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  <Plus size={20} />
                  Add Product
                </button>
              </div>

              <div className="bg-white rounded-lg shadow overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {products.map((product) => (
                      <tr key={product.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <img className="h-10 w-10 rounded-md object-cover" src={product.image} alt={product.name} />
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{product.name}</div>
                              <div className="text-sm text-gray-500">{product.brand}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatPrice(product.price)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {product.category}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                            product.in_stock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {product.in_stock ? 'In Stock' : 'Out of Stock'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => {
                              handleEditProduct(product);
                              setActiveTab('add-product');
                            }}
                            className="text-blue-600 hover:text-blue-900 mr-4"
                          >
                            <Edit size={16} />
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(product.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'add-product' && (
            <div className="p-6">
              <h3 className="text-2xl font-bold mb-6">
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h3>
              
              <div className="bg-white rounded-lg shadow p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Product Name</label>
                    <input
                      type="text"
                      value={newProduct.name}
                      onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter product name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Brand</label>
                    <input
                      type="text"
                      value={newProduct.brand}
                      onChange={(e) => setNewProduct({ ...newProduct, brand: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter brand name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Price (₹)</label>
                    <input
                      type="number"
                      value={newProduct.price}
                      onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter price"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Original Price (₹)</label>
                    <input
                      type="number"
                      value={newProduct.original_price}
                      onChange={(e) => setNewProduct({ ...newProduct, original_price: Number(e.target.value) })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter original price"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Discount (%)</label>
                    <input
                      type="number"
                      value={newProduct.discount}
                      onChange={(e) => setNewProduct({ ...newProduct, discount: Number(e.target.value) })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter discount percentage"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                    <select
                      value={newProduct.category}
                      onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Electronics">Electronics</option>
                      <option value="Fashion">Fashion</option>
                      <option value="Home">Home</option>
                      <option value="Books">Books</option>
                      <option value="Sports">Sports</option>
                      <option value="Beauty">Beauty</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Main Image URL</label>
                    <input
                      type="url"
                      value={newProduct.image}
                      onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter main image URL"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="5"
                      value={newProduct.rating}
                      onChange={(e) => setNewProduct({ ...newProduct, rating: Number(e.target.value) })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter rating (0-5)"
                    />
                  </div>
                </div>
                
                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    value={newProduct.description}
                    onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={4}
                    placeholder="Enter product description"
                  />
                </div>
                
                {/* Additional Images */}
                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Additional Images</label>
                  {newProduct.images.map((image, index) => (
                    <div key={index} className="flex gap-2 mb-2">
                      <input
                        type="url"
                        value={image}
                        onChange={(e) => updateImage(index, e.target.value)}
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter image URL"
                      />
                      <button
                        type="button"
                        onClick={() => removeImage(index)}
                        className="px-3 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={addImage}
                    className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                  >
                    Add Image
                  </button>
                </div>
                
                {/* Features */}
                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Features</label>
                  {newProduct.features.map((feature, index) => (
                    <div key={index} className="flex gap-2 mb-2">
                      <input
                        type="text"
                        value={feature}
                        onChange={(e) => updateFeature(index, e.target.value)}
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter feature"
                      />
                      <button
                        type="button"
                        onClick={() => removeFeature(index)}
                        className="px-3 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={addFeature}
                    className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                  >
                    Add Feature
                  </button>
                </div>
                
                {/* Checkboxes */}
                <div className="mt-6 grid grid-cols-3 gap-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={newProduct.in_stock}
                      onChange={(e) => setNewProduct({ ...newProduct, in_stock: e.target.checked })}
                      className="mr-2"
                    />
                    In Stock
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={newProduct.fast_delivery}
                      onChange={(e) => setNewProduct({ ...newProduct, fast_delivery: e.target.checked })}
                      className="mr-2"
                    />
                    Fast Delivery
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={newProduct.free_delivery}
                      onChange={(e) => setNewProduct({ ...newProduct, free_delivery: e.target.checked })}
                      className="mr-2"
                    />
                    Free Delivery
                  </label>
                </div>
                
                <div className="mt-8 flex gap-4">
                  <button
                    onClick={handleSaveProduct}
                    disabled={loading}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                  >
                    <Save size={20} />
                    {loading ? 'Saving...' : 'Save Product'}
                  </button>
                  <button
                    onClick={() => {
                      setEditingProduct(null);
                      resetProductForm();
                      setActiveTab('products');
                    }}
                    className="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="p-6">
              <h3 className="text-2xl font-bold mb-6">Orders Management</h3>
              
              {loading ? (
                <div className="text-center py-8">Loading orders...</div>
              ) : orders.length === 0 ? (
                <div className="text-center py-8">
                  <ShoppingCart size={64} className="mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No orders found</h3>
                  <p className="text-gray-500">Orders will appear here when customers place them.</p>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {orders.map((order) => (
                        <tr key={order.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            #{order.id.slice(0, 8)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">{order.users?.name}</div>
                            <div className="text-sm text-gray-500">{order.users?.email}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatPrice(order.total)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <select
                              value={order.status}
                              onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value)}
                              className={`text-xs font-semibold rounded-full px-2 py-1 border-0 ${getStatusColor(order.status)}`}
                            >
                              <option value="pending">Pending</option>
                              <option value="confirmed">Confirmed</option>
                              <option value="shipped">Shipped</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatDate(order.created_at)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => setEditingOrder(order)}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              <Eye size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Order Details Modal */}
              {editingOrder && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                  <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                    <div className="flex items-center justify-between p-6 border-b">
                      <h3 className="text-xl font-semibold">Order Details</h3>
                      <button
                        onClick={() => setEditingOrder(null)}
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                      >
                        <X size={20} />
                      </button>
                    </div>
                    <div className="p-6 space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-semibold mb-4">Order Information</h4>
                          <div className="space-y-2">
                            <p><strong>Order ID:</strong> #{editingOrder.id}</p>
                            <p><strong>Date:</strong> {formatDate(editingOrder.created_at)}</p>
                            <p><strong>Status:</strong> <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(editingOrder.status)}`}>{editingOrder.status}</span></p>
                            <p><strong>Payment Status:</strong> {editingOrder.payment_status}</p>
                            <p><strong>Total:</strong> {formatPrice(editingOrder.total)}</p>
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold mb-4">Customer Information</h4>
                          <div className="space-y-2">
                            <p><strong>Name:</strong> {editingOrder.users?.name}</p>
                            <p><strong>Email:</strong> {editingOrder.users?.email}</p>
                            <p><strong>Phone:</strong> {editingOrder.users?.phone || 'Not provided'}</p>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-4">Items Ordered</h4>
                        <div className="space-y-3">
                          {editingOrder.items.map((item: any, index: number) => (
                            <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                              <div>
                                <span className="font-medium">{item.product_name}</span>
                                <span className="text-gray-500 ml-2">x {item.quantity}</span>
                              </div>
                              <span className="font-semibold">{formatPrice(item.total)}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {editingOrder.shipping_address && (
                        <div>
                          <h4 className="font-semibold mb-4">Shipping Address</h4>
                          <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="font-medium">{editingOrder.shipping_address.name}</p>
                            <p>{editingOrder.shipping_address.street}</p>
                            <p>{editingOrder.shipping_address.city}, {editingOrder.shipping_address.state} - {editingOrder.shipping_address.pincode}</p>
                            <p>Phone: {editingOrder.shipping_address.phone}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'users' && (
            <div className="p-6">
              <h3 className="text-2xl font-bold mb-6">Users Management</h3>
              <p className="text-gray-600">Users management functionality will be implemented here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}