import React from 'react';
import { motion } from 'framer-motion';
import { Filter, X } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface ProductFiltersProps {
  sortBy: string;
  setSortBy: (sort: string) => void;
  priceRange: number[];
  setPriceRange: (range: number[]) => void;
  selectedBrands: string[];
  setSelectedBrands: (brands: string[]) => void;
}

export default function ProductFilters({
  sortBy,
  setSortBy,
  priceRange,
  setPriceRange,
  selectedBrands,
  setSelectedBrands
}: ProductFiltersProps) {
  const { isDark } = useTheme();

  const brands = ['Apple', 'Samsung', 'Nike', 'Levi\'s', 'Sony'];
  const categories = ['Electronics', 'Fashion', 'Home', 'Books', 'Sports', 'Beauty'];

  const handleBrandToggle = (brand: string) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter(b => b !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  const clearFilters = () => {
    setSortBy('featured');
    setPriceRange([0, 200000]);
    setSelectedBrands([]);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className={`p-6 rounded-2xl h-fit sticky top-24 ${
        isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-purple-100'
      } shadow-lg`}
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className={`text-lg font-bold flex items-center gap-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
          <Filter size={20} />
          Filters
        </h3>
        <button
          onClick={clearFilters}
          className={`text-sm hover:underline ${isDark ? 'text-purple-400' : 'text-purple-600'}`}
        >
          Clear All
        </button>
      </div>

      {/* Sort By */}
      <div className="mb-6">
        <h4 className={`font-semibold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
          Sort By
        </h4>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className={`w-full p-3 rounded-xl border ${
            isDark 
              ? 'bg-gray-700 border-gray-600 text-white' 
              : 'bg-white border-gray-300'
          } focus:outline-none focus:ring-2 focus:ring-purple-500`}
        >
          <option value="featured">Featured</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
          <option value="rating">Customer Rating</option>
          <option value="newest">Newest First</option>
        </select>
      </div>

      {/* Price Range */}
      <div className="mb-6">
        <h4 className={`font-semibold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
          Price Range
        </h4>
        <div className="space-y-3">
          <input
            type="range"
            min="0"
            max="200000"
            step="1000"
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
            className="w-full accent-purple-600"
          />
          <div className="flex justify-between text-sm">
            <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>₹0</span>
            <span className={isDark ? 'text-gray-300' : 'text-gray-600'}>₹{priceRange[1].toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Brands */}
      <div className="mb-6">
        <h4 className={`font-semibold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
          Brands
        </h4>
        <div className="space-y-2">
          {brands.map((brand) => (
            <label key={brand} className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={selectedBrands.includes(brand)}
                onChange={() => handleBrandToggle(brand)}
                className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
              />
              <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                {brand}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="mb-6">
        <h4 className={`font-semibold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
          Categories
        </h4>
        <div className="space-y-2">
          {categories.map((category) => (
            <button
              key={category}
              className={`block w-full text-left p-2 rounded-lg transition-colors ${
                isDark 
                  ? 'hover:bg-gray-700 text-gray-300' 
                  : 'hover:bg-gray-100 text-gray-700'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Rating Filter */}
      <div className="mb-6">
        <h4 className={`font-semibold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
          Customer Rating
        </h4>
        <div className="space-y-2">
          {[4, 3, 2, 1].map((rating) => (
            <button
              key={rating}
              className={`flex items-center gap-2 w-full text-left p-2 rounded-lg transition-colors ${
                isDark 
                  ? 'hover:bg-gray-700 text-gray-300' 
                  : 'hover:bg-gray-100 text-gray-700'
              }`}
            >
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <span
                    key={i}
                    className={`text-sm ${
                      i < rating ? 'text-yellow-400' : 'text-gray-300'
                    }`}
                  >
                    ★
                  </span>
                ))}
              </div>
              <span className="text-sm">& Up</span>
            </button>
          ))}
        </div>
      </div>

      {/* Delivery Options */}
      <div>
        <h4 className={`font-semibold mb-3 ${isDark ? 'text-white' : 'text-gray-800'}`}>
          Delivery Options
        </h4>
        <div className="space-y-2">
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
            />
            <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              Fast Delivery
            </span>
          </label>
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
            />
            <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              Free Delivery
            </span>
          </label>
        </div>
      </div>
    </motion.div>
  );
}