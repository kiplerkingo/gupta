import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import ProductCard from './ProductCard';
import LoadingSpinner from './LoadingSpinner';
import { products } from '../data/products';
import { useTheme } from '../context/ThemeContext';
import { useApp } from '../context/AppContext';

export default function RecommendedProducts() {
  const { isDark } = useTheme();
  const { state } = useApp();
  const [loading, setLoading] = useState(true);
  const [recommendedProducts, setRecommendedProducts] = useState(products);

  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  useEffect(() => {
    // Simulate loading and personalization
    const timer = setTimeout(() => {
      if (state.isAuthenticated) {
        // Personalized recommendations based on user behavior
        const userCategories = state.wishlist.map(item => item.category);
        const personalizedProducts = products.filter(product => 
          userCategories.includes(product.category)
        );
        
        if (personalizedProducts.length > 0) {
          setRecommendedProducts([...personalizedProducts, ...products.filter(p => 
            !personalizedProducts.includes(p)
          )].slice(0, 8));
        }
      } else {
        // Show trending/popular products for non-authenticated users
        setRecommendedProducts(products.slice(0, 8));
      }
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, [state.isAuthenticated, state.wishlist]);

  if (loading) {
    return (
      <div className={`py-16 ${isDark ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4">
          <LoadingSpinner />
        </div>
      </div>
    );
  }

  return (
    <div className={`py-16 ${isDark ? 'bg-gray-900' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          className="text-center mb-12"
        >
          <h2 className={`text-3xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
            {state.isAuthenticated ? 'Recommended for You' : 'Trending Products'}
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            {state.isAuthenticated 
              ? 'Curated based on your interests and shopping history'
              : 'Discover what\'s popular among our customers'
            }
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {recommendedProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <ProductCard product={product} />
            </motion.div>
          ))}
        </motion.div>

        {state.isAuthenticated && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ delay: 1.0 }}
            className="text-center mt-12"
          >
            <button className={`px-8 py-3 rounded-full font-semibold transition-all ${
              isDark 
                ? 'bg-purple-600 hover:bg-purple-700 text-white' 
                : 'bg-purple-600 hover:bg-purple-700 text-white'
            }`}>
              View More Recommendations
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}