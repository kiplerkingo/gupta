import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-bold mb-4">
              Gupta<span className="text-yellow-400">&Sons</span>
            </div>
            <p className="text-gray-400 mb-4">
              India's leading e-commerce platform offering the best products at competitive prices.
            </p>
            <div className="flex space-x-4">
              <Facebook size={20} className="hover:text-blue-500 cursor-pointer transition-colors" />
              <Twitter size={20} className="hover:text-blue-400 cursor-pointer transition-colors" />
              <Instagram size={20} className="hover:text-pink-500 cursor-pointer transition-colors" />
              <Youtube size={20} className="hover:text-red-500 cursor-pointer transition-colors" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2 text-gray-400">
              <li><Link to="/help" className="hover:text-white transition-colors">Help Center</Link></li>
              <li><Link to="/returns" className="hover:text-white transition-colors">Returns & Refunds</Link></li>
              <li><Link to="/shipping" className="hover:text-white transition-colors">Shipping Info</Link></li>
              <li><Link to="/track-order" className="hover:text-white transition-colors">Track Your Order</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">About Gupta & Sons</h3>
            <ul className="space-y-2 text-gray-400">
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/careers" className="hover:text-white transition-colors">Careers</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Press</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Investor Relations</Link></li>
              <li><Link to="/sell" className="hover:text-white transition-colors">Sell on Gupta & Sons</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-3 text-gray-400">
              <div className="flex items-center gap-3">
                <Phone size={16} />
                <span>8839107369</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={16} />
                <span>support@guptaandson.in</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin size={16} />
                <span>Bhopal, Madhya Pradesh, India</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 Gupta & Sons. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="/privacy-policy" className="text-gray-400 hover:text-white text-sm transition-colors">Privacy Policy</Link>
              <Link to="/terms" className="text-gray-400 hover:text-white text-sm transition-colors">Terms of Service</Link>
              <Link to="/returns-refunds" className="text-gray-400 hover:text-white text-sm transition-colors">Returns Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}