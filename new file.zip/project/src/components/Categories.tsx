import React from 'react';
import { categories } from '../data/products';
import * as Icons from 'lucide-react';

interface CategoriesProps {
  onCategorySelect: (category: string) => void;
}

export default function Categories({ onCategorySelect }: CategoriesProps) {
  return (
    <div className="bg-white py-8">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => {
            const IconComponent = Icons[category.icon as keyof typeof Icons] as React.ComponentType<{ size?: number; className?: string }>;
            
            return (
              <button
                key={category.id}
                onClick={() => onCategorySelect(category.name)}
                className="flex flex-col items-center p-6 bg-gray-50 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-all duration-200 group"
              >
                <div className="w-12 h-12 mb-3 text-blue-600 group-hover:scale-110 transition-transform">
                  <IconComponent size={48} />
                </div>
                <span className="font-medium text-gray-800 group-hover:text-blue-600">
                  {category.name}
                </span>
                <span className="text-xs text-gray-500 mt-1">
                  {category.subcategories.length} items
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}