import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-razorpay-signature',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface RazorpayWebhookPayload {
  entity: string;
  account_id: string;
  event: string;
  contains: string[];
  payload: {
    payment: {
      entity: {
        id: string;
        entity: string;
        amount: number;
        currency: string;
        status: string;
        order_id: string;
        invoice_id: string | null;
        international: boolean;
        method: string;
        amount_refunded: number;
        refund_status: string | null;
        captured: boolean;
        description: string;
        card_id: string | null;
        bank: string | null;
        wallet: string | null;
        vpa: string | null;
        email: string;
        contact: string;
        notes: Record<string, any>;
        fee: number;
        tax: number;
        error_code: string | null;
        error_description: string | null;
        error_source: string | null;
        error_step: string | null;
        error_reason: string | null;
        acquirer_data: Record<string, any>;
        created_at: number;
      };
    };
  };
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get the webhook payload
    const payload: RazorpayWebhookPayload = await req.json()
    
    console.log('Received webhook:', payload.event)

    // Handle payment captured event
    if (payload.event === 'payment.captured') {
      const payment = payload.payload.payment.entity
      
      console.log('Processing payment captured:', payment.id)

      // Update order status in database
      const { error } = await supabaseClient
        .from('orders')
        .update({
          payment_id: payment.id,
          payment_status: 'completed',
          status: 'confirmed',
          updated_at: new Date().toISOString()
        })
        .eq('payment_id', payment.id)

      if (error) {
        console.error('Error updating order:', error)
        throw error
      }

      console.log('Order updated successfully for payment:', payment.id)
    }

    // Handle payment failed event
    if (payload.event === 'payment.failed') {
      const payment = payload.payload.payment.entity
      
      console.log('Processing payment failed:', payment.id)

      // Update order status in database
      const { error } = await supabaseClient
        .from('orders')
        .update({
          payment_id: payment.id,
          payment_status: 'failed',
          status: 'cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('payment_id', payment.id)

      if (error) {
        console.error('Error updating failed order:', error)
        throw error
      }

      console.log('Order marked as failed for payment:', payment.id)
    }

    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    console.error('Webhook error:', error)
    
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})