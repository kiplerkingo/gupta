/*
  # Initial E-commerce Database Schema

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `name` (text)
      - `phone` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `price` (numeric)
      - `original_price` (numeric)
      - `discount` (integer)
      - `rating` (numeric)
      - `reviews` (integer)
      - `image` (text)
      - `images` (jsonb)
      - `category` (text)
      - `brand` (text)
      - `description` (text)
      - `features` (jsonb)
      - `specifications` (jsonb)
      - `in_stock` (boolean)
      - `fast_delivery` (boolean)
      - `free_delivery` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `orders`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `items` (jsonb)
      - `total` (numeric)
      - `status` (text)
      - `payment_id` (text)
      - `payment_status` (text)
      - `shipping_address` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  original_price numeric DEFAULT 0,
  discount integer DEFAULT 0,
  rating numeric DEFAULT 4.0,
  reviews integer DEFAULT 0,
  image text NOT NULL DEFAULT '',
  images jsonb DEFAULT '[]'::jsonb,
  category text NOT NULL DEFAULT 'Electronics',
  brand text NOT NULL DEFAULT '',
  description text DEFAULT '',
  features jsonb DEFAULT '[]'::jsonb,
  specifications jsonb DEFAULT '{}'::jsonb,
  in_stock boolean DEFAULT true,
  fast_delivery boolean DEFAULT false,
  free_delivery boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  total numeric NOT NULL DEFAULT 0,
  status text DEFAULT 'pending',
  payment_id text,
  payment_status text DEFAULT 'pending',
  shipping_address jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = id::text);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = id::text);

CREATE POLICY "Users can insert own data"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = id::text);

-- Create policies for products table
CREATE POLICY "Anyone can read products"
  ON products
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Admin can manage products"
  ON products
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id::text = auth.uid()::text 
      AND users.email = 'admin@guptaandson.in'
    )
  );

-- Create policies for orders table
CREATE POLICY "Users can read own orders"
  ON orders
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can create own orders"
  ON orders
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = user_id::text);

CREATE POLICY "Admin can read all orders"
  ON orders
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id::text = auth.uid()::text 
      AND users.email = 'admin@guptaandson.in'
    )
  );

-- Insert sample products with proper UUID values
INSERT INTO products (id, name, price, original_price, discount, rating, reviews, image, images, category, brand, description, features, specifications, in_stock, fast_delivery, free_delivery) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'iPhone 15 Pro Max', 159900, 179900, 11, 4.6, 1247, 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg', '["https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg", "https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg"]', 'Electronics', 'Apple', 'The most advanced iPhone yet with titanium design, A17 Pro chip, and professional camera system.', '["6.7\" Super Retina XDR display", "A17 Pro chip", "Pro camera system", "Titanium design"]', '{"Screen Size": "6.7 inches", "Storage": "256GB", "RAM": "8GB", "Battery": "4441 mAh", "OS": "iOS 17"}', true, true, true),
('550e8400-e29b-41d4-a716-446655440002', 'Samsung Galaxy S24 Ultra', 124999, 134999, 7, 4.5, 892, 'https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg', '["https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg", "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg"]', 'Electronics', 'Samsung', 'Premium Android flagship with S Pen, exceptional cameras, and AI-powered features.', '["6.8\" Dynamic AMOLED display", "Snapdragon 8 Gen 3", "S Pen included", "200MP camera"]', '{"Screen Size": "6.8 inches", "Storage": "256GB", "RAM": "12GB", "Battery": "5000 mAh", "OS": "Android 14"}', true, true, true),
('550e8400-e29b-41d4-a716-446655440003', 'MacBook Pro 14" M3', 199900, 219900, 9, 4.8, 567, 'https://images.pexels.com/photos/812264/pexels-photo-812264.jpeg', '["https://images.pexels.com/photos/812264/pexels-photo-812264.jpeg", "https://images.pexels.com/photos/1591056/pexels-photo-1591056.jpeg"]', 'Electronics', 'Apple', 'Professional laptop with M3 chip, stunning Liquid Retina XDR display, and all-day battery life.', '["14\" Liquid Retina XDR display", "M3 chip", "18-hour battery", "Professional performance"]', '{"Screen Size": "14.2 inches", "Processor": "Apple M3", "RAM": "16GB", "Storage": "512GB SSD", "OS": "macOS Sonoma"}', true, false, true),
('550e8400-e29b-41d4-a716-446655440004', 'Nike Air Jordan 1 Retro High', 12295, 13995, 12, 4.4, 2156, 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg', '["https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg", "https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg"]', 'Fashion', 'Nike', 'Iconic basketball sneaker with premium leather construction and classic colorway.', '["Premium leather upper", "Air-Sole unit", "Rubber outsole", "Classic design"]', '{"Material": "Leather", "Sole": "Rubber", "Closure": "Laces", "Heel Height": "1 inch", "Weight": "450g"}', true, true, false),
('550e8400-e29b-41d4-a716-446655440005', 'Sony WH-1000XM5 Headphones', 29990, 34999, 14, 4.7, 1834, 'https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg', '["https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg", "https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg"]', 'Electronics', 'Sony', 'Industry-leading noise canceling headphones with exceptional sound quality and comfort.', '["Industry-leading noise canceling", "30-hour battery", "Quick charge", "Multipoint connection"]', '{"Type": "Over-ear", "Battery Life": "30 hours", "Connectivity": "Bluetooth 5.2", "Weight": "250g", "Driver Size": "30mm"}', true, true, true),
('550e8400-e29b-41d4-a716-446655440006', 'Levi''s 511 Slim Jeans', 3999, 4999, 20, 4.3, 3421, 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg', '["https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg", "https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg"]', 'Fashion', 'Levi''s', 'Classic slim-fit jeans with modern styling and comfortable stretch denim.', '["Slim fit", "Stretch denim", "Classic 5-pocket styling", "Versatile design"]', '{"Fit": "Slim", "Material": "99% Cotton, 1% Elastane", "Wash": "Dark Blue", "Rise": "Mid Rise", "Leg Opening": "14.5 inches"}', true, true, false);